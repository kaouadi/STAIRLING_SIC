# Staircoach Design System

> Staircoach simplifie le quotidien des coachs sportifs.

Staircoach (by **Stairling Technologies**) is a professional platform for sports coaches. It transforms coaching — today a precarious, fragmented trade — into a **structured, durable, and credible profession**, serving coaches, territories, and organizations.

This design system captures the voice, visual language, and UI vocabulary used across Staircoach surfaces (marketing site, coach dashboard, pitch deck).

---

## Sources provided

| Source | Path / URL | Notes |
|---|---|---|
| Logo | `uploads/Stairling.png` → `assets/staircoach-logo.png` | Geometric "S" built from two slanted slabs. Black on transparent, 796×688. |
| Pitch deck | `uploads/Staircoach-Google Slides.pptx` | 6 slides, 16:9 (1280×720). Roboto, `#F3F3F3` light-gray backgrounds, real coach photography, Material Symbols icons. All media extracted to `assets/slides-media/`. |
| Brand brief | In-chat | "Simplifie la vie quotidienne des coachs sportifs"; "activité professionnelle structurée, durable et crédible". Logo always in header. Footer: "Stairling Technologies". |

---

## Index

| File / folder | What it is |
|---|---|
| `README.md` | Overview, voice, visual foundations, iconography. |
| `SKILL.md` | Agent Skill manifest. |
| `colors_and_type.css` | Design tokens: color, type, spacing, radii, motion. Import this first. |
| `assets/` | Logo. |
| `assets/slides-media/` | Images lifted from the pitch deck (hero coach photo, gym/contract/dashboard stock, stair-step card art). |
| `preview/` | Small HTML cards rendered in the Design System tab. |
| `slides/` | Deck slide recreations (title, problem, promise, 3-pillars, benefits, closing). |
| `ui_kits/website/` | UI kit for the Staircoach marketing site (components + clickable index.html). |

---

## Brand positioning

- **What it is**: A SaaS platform that structures the daily life of sports coaches — legal framework, scheduling, client management, invoicing, training, community.
- **Who it's for**: Independent sports coaches in France (primary), plus sports federations, municipalities ("territoires"), and organizations who work with them.
- **Voice in one line**: *Professional, grounded, confident. Not a fitness hype app — a business tool for people whose business is movement.*

---

## CONTENT FUNDAMENTALS

Staircoach copy is **French-first**, written for working professionals. The tone mirrors serious business SaaS — not consumer fitness apps.

### Voice principles
- **Concrete over aspirational.** Talk about the job, not the dream. The deck's problem framing is explicit — *"Statut Micro-entreprise… Peu de protection sociale"*, *"Taux d'abandon à 24 mois : 63%"*. No vague promises.
- **Name the numbers.** Real stats anchor the pitch: *63%* abandon rate, *+385€/mois* earnings gain. When a claim is quantifiable, quantify it.
- **Respect the reader's time.** Short sentences. Verbs first. One idea per line. The deck uses tight bullet rhythm — follow it.
- **Credibility is the product.** The words *structuré, durable, crédible, professionnel, métier, cadre, sécurisé* appear across the deck. These aren't decorations — they're the value prop.
- **Vous, not tu** in marketing and formal contexts. Coaches are addressed formally. (*Note*: the deck occasionally slips into *tu* — *"Développe ton activité"* — we recommend normalizing to *vous* throughout the product surface.)
- **No emoji. No exclamation marks** as a rule.
- **French beats Franglais**: *tableau de bord*, not *dashboard*; *séance*, not *session*.

### Casing
- **Sentence case** for everything: buttons, headings, nav, labels. The deck follows this (*"Le problème (côté coach)"*, *"La promesse Staircoach"*, *"Comment ça marche : les 3 piliers"*).
- Proper nouns (Staircoach, Stairling, URSSAF) keep their caps.

### Numbers & data
- French number formatting: `1 245 €`, `63 %`, `+385 €/mois`. Non-breaking space before `€` and `%`.
- Dates: `jeu. 22 avr.` compact, `jeudi 22 avril 2026` full.
- Times: 24h, `09:00 – 10:30`.

### Example copy (lifted from the deck)

| Context | Example |
|---|---|
| Hero tagline | *Staircoach simplifie le quotidien des coachs sportifs.* |
| Section title | *Le problème (côté coach)* |
| Promise | *La stabilité d'une structure, sans perdre votre liberté.* |
| Pillar label | *Cadre légal sécurisé* |
| Benefit headline | *Plus de revenus — +385 €/mois sur 2 500 € de CA.* |
| Bullet | *Gestion admin complète (paie, cotisations, URSSAF, assurances)* |

### Vibe
Confident, plainspoken, a little severe. The design and copy both say: *"Your work matters. We treat it seriously."*

---

## VISUAL FOUNDATIONS

### Palette
Monochromatic with warm neutrals. The deck lives on **light gray `#F3F3F3`** with **black `#0A0A0A`** type — no color accents. We keep this discipline across the system.

- `--bg` `#F8F8F7` — warm off-white page background (close to deck's `#F3F3F3`)
- `--paper` `#FFFFFF` — elevated surfaces (cards, modals, inputs)
- `--ink-900` `#0A0A0A` — text, logo, borders-on-focus
- `--ink-200` `#E6E6E6` — hairline borders (the default separator)
- `--accent` `#0A0A0A` — CTA fills are black-on-white or white-on-black. No chromatic accent.

Semantic signal colors (`--signal`, `--success`, `--warning`, `--danger`) exist for system states only (toasts, validation, charts). Marketing never uses them.

### Typography
- **Single family**: **Roboto** (used throughout the deck). **Black 900** for title-slide hero and hero numbers; **Bold 700** for H1/H2/section labels; **Medium 500** for body emphasis and UI; **Regular 400** for body.
- **Mono**: *Roboto Mono* for tabular numbers (invoices, session IDs, timecodes).

Tracking is snug at display (`-0.02em`), neutral for body. Eyebrows / meta labels use uppercase + `0.14em` tracking for a credibility cue.

### Spacing
4pt base scale. Pages breathe — `--sp-20` (80px) section padding on desktop, `--sp-10` on mobile. Components use `--sp-4` / `--sp-6` internal padding.

### Backgrounds
- **No gradients.** The deck is flat `#F3F3F3` everywhere.
- **No repeating patterns / textures.**
- **Documentary photography is central.** The deck leans on:
  - Real coaches in real spaces — gym, trail, outdoor — natural light, moody cool tones. See `image5.jpg` (coach in CrossFit Louvre tee), `image16.jpg` (coach + trainee barbell).
  - Context stills — contracts, phone mockups, gym floors — for the admin/legal/tool narrative.
- Do NOT: use bright blue-gradient stock, shiny-machine gym close-ups, over-saturated fitness imagery, AI-obvious renders.

### Borders & separators
- **Hairline 1px borders** (`--ink-200`) default. Cards, inputs, table rows — all edged, none shadowed.
- Focused/active elements shift to 1px black border.

### Shadows
Shadows are rare and soft. Elevation comes from borders and whitespace.

### Corner radii
Cards in the deck use **~16–20px rounded corners** (see `image3.png` — a white rounded-rect card art used as the background for the "promesse" two-column layout). So in the *marketing/deck* context, cards get `--r-md` to `--r-lg` rounding. In the *product UI* context, we keep inputs at `--r-sm` (4px) for legibility. This is the one place radius varies by surface — flag in comments.

### Cards
Marketing card: white rectangle, 1px hairline border, **16–20px rounded corners**, optional very soft shadow (`--shadow-1`). Interior padding `--sp-8` / `--sp-10`. Can hold a large numbered eyebrow (01, 02, 03), a section title, bullets, and a bottom image.

### Buttons
- **Primary**: solid black fill, white text, `--r-md` radius, 48px tall, `font-weight: 700`. Hover: 6% lift darken.
- **Secondary**: white fill, 1px black border, black text.
- **Tertiary / ghost**: no fill, text only, underline on hover.

### Hover, press, focus
- **Hover (buttons)**: ~6% darken; border thickens to 2px for outline styles.
- **Hover (cards)**: border darkens from `--ink-200` → `--ink-900`; no lift.
- **Hover (links)**: underline goes from `--ink-300` → `--ink-900`.
- **Press**: scale(0.98) or `translateY(1px)`.
- **Focus**: blue ring (`--shadow-focus`). Never removed.

### Motion
Restrained. Ease-out / ease-in-out only.
- `--dur-fast` 120ms (hovers), `--dur-med` 220ms (reveals), `--dur-slow` 420ms (large layout shifts).
- Fades + 4–8px translations. Scale reserved for press.

### Transparency & blur
Sticky nav: white 85% + `backdrop-filter: blur(12px)`. Modal overlay: ink-900 at 50%. Nothing else.

### Layout rules
- Desktop canvas: centered 1200px max-width, `--sp-20` outside gutter.
- Grid: 12-col desktop, 4-col mobile, gutter `--sp-6`.
- Sticky header: 64px tall, 1px bottom border, white background. **Logo always present top-left** (per brief + deck).
- Footer: black background, white text, **"Stairling Technologies"** + legal. Always present.

### Logo usage
- Minimum size: 24px tall. Clear space: one "slab-height" padding on all sides.
- Black on light; white on dark. Never recolor, tilt, or outline.
- "Staircoach" wordmark (when needed) sits to the right of the mark in Roboto Black.

---

## ICONOGRAPHY

**Approach**: **Material Symbols Outlined** — confirmed from the deck, which references icons by their Material names literally (`person_outline`, `verified_user`). Default grade 0, weight 400, optical size 24.

**Source**: Loaded from Google Fonts CDN in `colors_and_type.css`:

```css
@import url('https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0');
```

Usage pattern:
```html
<span class="icon">person_outline</span>
<span class="icon">verified_user</span>
<span class="icon">calendar_month</span>
<span class="icon">euro</span>
<span class="icon">event</span>
<span class="icon">group</span>
<span class="icon">receipt_long</span>
<span class="icon">settings</span>
```

**Never** use:
- Emoji as UI.
- Colored / multi-color icon sets.
- Filled Material variants (we keep `FILL: 0` — outlined only).
- Unicode symbols (✓, →, ★) — use the SVG/Material equivalent for consistency.

**Key icons used in Staircoach context**:
- `person_outline` / `group` — coach, clients
- `verified_user` / `shield` — legal, protection
- `event` / `calendar_month` — scheduling, séances
- `euro` / `receipt_long` — revenue, facturation
- `school` — training, accompagnement
- `location_on` — territoires
- `trending_up` — growth, performance

---

## Design system preview

See the **Design System** tab for every registered card.
