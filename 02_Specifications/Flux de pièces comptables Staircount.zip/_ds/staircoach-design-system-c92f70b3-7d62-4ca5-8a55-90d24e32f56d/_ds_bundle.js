/* @ds-bundle: {"format":3,"namespace":"StaircoachDesignSystem_c92f70","components":[],"sourceHashes":{"ui_kits/website/BenefitsSection.jsx":"9c839e4b860c","ui_kits/website/CTASection.jsx":"1a90f1e5f617","ui_kits/website/Footer.jsx":"234f31ccc6ef","ui_kits/website/Header.jsx":"eaf5ca93eca2","ui_kits/website/Hero.jsx":"3c220bdfdba5","ui_kits/website/PillarsSection.jsx":"51f224677f98","ui_kits/website/ProblemSection.jsx":"82a5331fe56e","ui_kits/website/PromiseSection.jsx":"814d9e7db12e"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.StaircoachDesignSystem_c92f70 = window.StaircoachDesignSystem_c92f70 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// ui_kits/website/BenefitsSection.jsx
try { (() => {
// BenefitsSection.jsx
const BenefitsSection = () => /*#__PURE__*/React.createElement("section", {
  className: "sc-section",
  id: "tarifs"
}, /*#__PURE__*/React.createElement("div", {
  className: "sc-section-head"
}, /*#__PURE__*/React.createElement("p", {
  className: "sc-eyebrow"
}, "Ce que vous gagnez"), /*#__PURE__*/React.createElement("h2", {
  className: "sc-h1"
}, "Plus de revenus, plus de s\xE9r\xE9nit\xE9.")), /*#__PURE__*/React.createElement("div", {
  className: "sc-grid-3 sc-grid-wide-first"
}, /*#__PURE__*/React.createElement("article", {
  className: "sc-card sc-card-padded sc-card-dark"
}, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
  className: "icon sc-icon-lg"
}, "trending_up"), /*#__PURE__*/React.createElement("h3", {
  className: "sc-h3"
}, "Plus de revenus"), /*#__PURE__*/React.createElement("div", {
  className: "sc-muted"
}, "Plus de net \xE0 chiffre d'affaires \xE9quivalent.")), /*#__PURE__*/React.createElement("div", {
  className: "sc-stat-hero"
}, /*#__PURE__*/React.createElement("div", {
  className: "sc-stat-hero-num"
}, "+385", /*#__PURE__*/React.createElement("span", null, "\xA0\u20AC")), /*#__PURE__*/React.createElement("div", {
  className: "sc-stat-hero-lbl"
}, "/mois sur 2 500 \u20AC de CA"))), /*#__PURE__*/React.createElement("article", {
  className: "sc-card sc-card-padded"
}, /*#__PURE__*/React.createElement("span", {
  className: "icon sc-icon-lg"
}, "verified_user"), /*#__PURE__*/React.createElement("h3", {
  className: "sc-h3"
}, "S\xE9curit\xE9 totale"), /*#__PURE__*/React.createElement("ul", {
  className: "sc-bullets"
}, /*#__PURE__*/React.createElement("li", null, "Protection sociale compl\xE8te"), /*#__PURE__*/React.createElement("li", null, "Cadre l\xE9gal rassurant"), /*#__PURE__*/React.createElement("li", null, "Acc\xE8s facilit\xE9 au logement"))), /*#__PURE__*/React.createElement("article", {
  className: "sc-card sc-card-padded"
}, /*#__PURE__*/React.createElement("span", {
  className: "icon sc-icon-lg"
}, "self_improvement"), /*#__PURE__*/React.createElement("h3", {
  className: "sc-h3"
}, "S\xE9r\xE9nit\xE9 d'esprit"), /*#__PURE__*/React.createElement("ul", {
  className: "sc-bullets"
}, /*#__PURE__*/React.createElement("li", null, "Moins de charge mentale (admin, conformit\xE9)"), /*#__PURE__*/React.createElement("li", null, "Plus de temps pour coacher"), /*#__PURE__*/React.createElement("li", null, "D\xE9veloppez votre activit\xE9")))));
window.BenefitsSection = BenefitsSection;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/BenefitsSection.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/CTASection.jsx
try { (() => {
// CTASection.jsx
const CTASection = () => {
  const [email, setEmail] = React.useState('');
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("section", {
    className: "sc-cta-block"
  }, /*#__PURE__*/React.createElement("p", {
    className: "sc-eyebrow sc-eyebrow-dark"
  }, "Rejoignez Staircoach"), /*#__PURE__*/React.createElement("h2", {
    className: "sc-display-sm"
  }, "Le m\xE9tier de coach,", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("em", null, "enfin structur\xE9.")), /*#__PURE__*/React.createElement("form", {
    className: "sc-signup",
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    }
  }, /*#__PURE__*/React.createElement("input", {
    className: "sc-input-dark",
    type: "email",
    placeholder: "votre@email.fr",
    value: email,
    onChange: e => setEmail(e.target.value),
    required: true
  }), /*#__PURE__*/React.createElement("button", {
    className: "sc-btn sc-btn-light",
    type: "submit"
  }, sent ? 'Merci !' : 'Commencer gratuitement', !sent && /*#__PURE__*/React.createElement("span", {
    className: "icon"
  }, "arrow_forward"))), /*#__PURE__*/React.createElement("p", {
    className: "sc-muted",
    style: {
      marginTop: 16
    }
  }, "Gratuit pendant 30 jours. Sans engagement."));
};
window.CTASection = CTASection;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/CTASection.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Footer.jsx
try { (() => {
// Footer.jsx
const Footer = () => /*#__PURE__*/React.createElement("footer", {
  className: "sc-footer"
}, /*#__PURE__*/React.createElement("div", {
  className: "sc-footer-top"
}, /*#__PURE__*/React.createElement("div", {
  className: "sc-footer-brand"
}, /*#__PURE__*/React.createElement("img", {
  src: "../../assets/staircoach-logo.png",
  alt: ""
}), /*#__PURE__*/React.createElement("span", null, "Staircoach")), /*#__PURE__*/React.createElement("div", {
  className: "sc-footer-cols"
}, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h5", null, "Produit"), /*#__PURE__*/React.createElement("a", {
  href: "#"
}, "Fonctionnalit\xE9s"), /*#__PURE__*/React.createElement("a", {
  href: "#"
}, "Tarifs"), /*#__PURE__*/React.createElement("a", {
  href: "#"
}, "S\xE9curit\xE9")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h5", null, "Ressources"), /*#__PURE__*/React.createElement("a", {
  href: "#"
}, "Blog"), /*#__PURE__*/React.createElement("a", {
  href: "#"
}, "Guides"), /*#__PURE__*/React.createElement("a", {
  href: "#"
}, "Webinaires")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h5", null, "Entreprise"), /*#__PURE__*/React.createElement("a", {
  href: "#"
}, "\xC0 propos"), /*#__PURE__*/React.createElement("a", {
  href: "#"
}, "Presse"), /*#__PURE__*/React.createElement("a", {
  href: "#"
}, "Contact")))), /*#__PURE__*/React.createElement("div", {
  className: "sc-footer-bottom"
}, /*#__PURE__*/React.createElement("div", null, "\xA9 2026 Stairling Technologies"), /*#__PURE__*/React.createElement("div", {
  className: "sc-footer-legal"
}, /*#__PURE__*/React.createElement("a", {
  href: "#"
}, "Mentions l\xE9gales"), /*#__PURE__*/React.createElement("a", {
  href: "#"
}, "CGU"), /*#__PURE__*/React.createElement("a", {
  href: "#"
}, "Confidentialit\xE9"))));
window.Footer = Footer;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Header.jsx
try { (() => {
// Header.jsx — sticky marketing nav
const Header = () => /*#__PURE__*/React.createElement("header", {
  className: "sc-header"
}, /*#__PURE__*/React.createElement("a", {
  href: "#",
  className: "sc-brand"
}, /*#__PURE__*/React.createElement("img", {
  src: "../../assets/staircoach-logo.png",
  alt: ""
}), /*#__PURE__*/React.createElement("span", null, "Staircoach")), /*#__PURE__*/React.createElement("nav", {
  className: "sc-nav"
}, /*#__PURE__*/React.createElement("a", {
  href: "#produit"
}, "Produit"), /*#__PURE__*/React.createElement("a", {
  href: "#pour-qui"
}, "Pour qui"), /*#__PURE__*/React.createElement("a", {
  href: "#tarifs"
}, "Tarifs"), /*#__PURE__*/React.createElement("a", {
  href: "#ressources"
}, "Ressources")), /*#__PURE__*/React.createElement("div", {
  className: "sc-header-actions"
}, /*#__PURE__*/React.createElement("a", {
  href: "#",
  className: "sc-link"
}, "Se connecter"), /*#__PURE__*/React.createElement("a", {
  href: "#",
  className: "sc-btn sc-btn-primary sc-btn-sm"
}, "Commencer")));
window.Header = Header;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Hero.jsx
try { (() => {
// Hero.jsx
const Hero = () => /*#__PURE__*/React.createElement("section", {
  className: "sc-hero"
}, /*#__PURE__*/React.createElement("div", {
  className: "sc-hero-left"
}, /*#__PURE__*/React.createElement("p", {
  className: "sc-eyebrow"
}, "Pour les coachs sportifs ind\xE9pendants"), /*#__PURE__*/React.createElement("h1", {
  className: "sc-display"
}, "Le m\xE9tier de coach,", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("em", null, "enfin structur\xE9.")), /*#__PURE__*/React.createElement("p", {
  className: "sc-lead"
}, "Staircoach simplifie votre quotidien : cadre l\xE9gal, facturation, protection sociale et accompagnement \u2014 sans perdre votre libert\xE9."), /*#__PURE__*/React.createElement("div", {
  className: "sc-cta-row"
}, /*#__PURE__*/React.createElement("a", {
  href: "#",
  className: "sc-btn sc-btn-primary"
}, "Commencer gratuitement"), /*#__PURE__*/React.createElement("a", {
  href: "#",
  className: "sc-btn sc-btn-ghost"
}, "Voir la d\xE9mo ", /*#__PURE__*/React.createElement("span", {
  className: "icon"
}, "arrow_forward"))), /*#__PURE__*/React.createElement("div", {
  className: "sc-trust"
}, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("strong", null, "1 200+"), /*#__PURE__*/React.createElement("span", null, "coachs accompagn\xE9s")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("strong", null, "+385 \u20AC"), /*#__PURE__*/React.createElement("span", null, "gain net moyen / mois")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("strong", null, "98 %"), /*#__PURE__*/React.createElement("span", null, "satisfaction")))), /*#__PURE__*/React.createElement("div", {
  className: "sc-hero-right"
}, /*#__PURE__*/React.createElement("img", {
  src: "../../assets/slides-media/image5.jpg",
  alt: ""
})));
window.Hero = Hero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/PillarsSection.jsx
try { (() => {
// PillarsSection.jsx
const PillarsSection = () => {
  const pillars = [{
    n: '01',
    title: 'Cadre légal sécurisé',
    img: 'image12.jpg',
    bullets: ['Gestion admin complète (paie, cotisations, URSSAF, assurances)', 'Vérification diplômes + conformité']
  }, {
    n: '02',
    title: 'Plateforme dédiée',
    img: 'image13.jpg',
    bullets: ['Suivi du CA, facturation, planning simplifiés', 'Simulation autonome du revenu']
  }, {
    n: '03',
    title: 'Accompagnement',
    img: 'image17.jpg',
    bullets: ['Coaching, formation, réseau', 'Partage d\u2019expérience entrepreneuriale']
  }];
  return /*#__PURE__*/React.createElement("section", {
    className: "sc-section",
    id: "ressources"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sc-section-head"
  }, /*#__PURE__*/React.createElement("p", {
    className: "sc-eyebrow"
  }, "Comment \xE7a marche"), /*#__PURE__*/React.createElement("h2", {
    className: "sc-h1"
  }, "Les 3 piliers Staircoach.")), /*#__PURE__*/React.createElement("div", {
    className: "sc-grid-3"
  }, pillars.map(p => /*#__PURE__*/React.createElement("article", {
    className: "sc-card sc-card-img",
    key: p.n
  }, /*#__PURE__*/React.createElement("img", {
    src: `../../assets/slides-media/${p.img}`,
    alt: ""
  }), /*#__PURE__*/React.createElement("div", {
    className: "sc-card-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sc-num"
  }, p.n), /*#__PURE__*/React.createElement("h3", {
    className: "sc-h3"
  }, p.title), /*#__PURE__*/React.createElement("ul", {
    className: "sc-bullets"
  }, p.bullets.map((b, i) => /*#__PURE__*/React.createElement("li", {
    key: i
  }, b))))))));
};
window.PillarsSection = PillarsSection;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/PillarsSection.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ProblemSection.jsx
try { (() => {
// ProblemSection.jsx
const ProblemSection = () => /*#__PURE__*/React.createElement("section", {
  className: "sc-section",
  id: "pour-qui"
}, /*#__PURE__*/React.createElement("div", {
  className: "sc-section-head"
}, /*#__PURE__*/React.createElement("p", {
  className: "sc-eyebrow"
}, "Le probl\xE8me (c\xF4t\xE9 coach)"), /*#__PURE__*/React.createElement("h2", {
  className: "sc-h1"
}, "Aujourd'hui, le coaching ind\xE9pendant ", /*#__PURE__*/React.createElement("em", null, "est pr\xE9caire et isol\xE9."))), /*#__PURE__*/React.createElement("div", {
  className: "sc-grid-2"
}, /*#__PURE__*/React.createElement("article", {
  className: "sc-card sc-card-img"
}, /*#__PURE__*/React.createElement("div", {
  className: "sc-card-body"
}, /*#__PURE__*/React.createElement("div", {
  className: "sc-tag"
}, "Statut Micro-entreprise"), /*#__PURE__*/React.createElement("h3", {
  className: "sc-h3"
}, "Peu de protection"), /*#__PURE__*/React.createElement("ul", {
  className: "sc-bullets"
}, /*#__PURE__*/React.createElement("li", null, "Pas de retraite, ch\xF4mage, ni mutuelle"), /*#__PURE__*/React.createElement("li", null, "Acc\xE8s limit\xE9 au cr\xE9dit et au logement"), /*#__PURE__*/React.createElement("li", null, "Fragilit\xE9 en cas d'arr\xEAt maladie"))), /*#__PURE__*/React.createElement("img", {
  src: "../../assets/slides-media/image15.jpg",
  alt: ""
})), /*#__PURE__*/React.createElement("article", {
  className: "sc-card sc-card-img"
}, /*#__PURE__*/React.createElement("div", {
  className: "sc-card-body"
}, /*#__PURE__*/React.createElement("div", {
  className: "sc-tag"
}, "Instabilit\xE9 professionnelle"), /*#__PURE__*/React.createElement("h3", {
  className: "sc-h3"
}, "Beaucoup abandonnent"), /*#__PURE__*/React.createElement("div", {
  className: "sc-stat"
}, /*#__PURE__*/React.createElement("div", {
  className: "sc-stat-num"
}, "63\xA0%"), /*#__PURE__*/React.createElement("div", {
  className: "sc-stat-lbl"
}, "Taux d'abandon \xE0 24 mois, malgr\xE9 un travail acharn\xE9."))), /*#__PURE__*/React.createElement("img", {
  src: "../../assets/slides-media/image14.jpg",
  alt: ""
}))));
window.ProblemSection = ProblemSection;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ProblemSection.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/PromiseSection.jsx
try { (() => {
// PromiseSection.jsx
const PromiseSection = () => /*#__PURE__*/React.createElement("section", {
  className: "sc-section",
  id: "produit"
}, /*#__PURE__*/React.createElement("div", {
  className: "sc-section-head"
}, /*#__PURE__*/React.createElement("p", {
  className: "sc-eyebrow"
}, "La promesse Staircoach"), /*#__PURE__*/React.createElement("h2", {
  className: "sc-h1"
}, "La stabilit\xE9 d'une structure,", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("em", null, "sans perdre votre libert\xE9."))), /*#__PURE__*/React.createElement("div", {
  className: "sc-grid-2"
}, /*#__PURE__*/React.createElement("article", {
  className: "sc-card sc-card-padded"
}, /*#__PURE__*/React.createElement("span", {
  className: "icon sc-icon-lg"
}, "person_outline"), /*#__PURE__*/React.createElement("h3", {
  className: "sc-h3"
}, "Libert\xE9 totale"), /*#__PURE__*/React.createElement("ul", {
  className: "sc-bullets"
}, /*#__PURE__*/React.createElement("li", null, "Gardez le contr\xF4le sur vos clients et lieux de coaching"), /*#__PURE__*/React.createElement("li", null, "Fixez vos propres tarifs librement"), /*#__PURE__*/React.createElement("li", null, "G\xE9rez votre emploi du temps et vos horaires"))), /*#__PURE__*/React.createElement("article", {
  className: "sc-card sc-card-padded"
}, /*#__PURE__*/React.createElement("span", {
  className: "icon sc-icon-lg"
}, "verified_user"), /*#__PURE__*/React.createElement("h3", {
  className: "sc-h3"
}, "Cadre professionnel"), /*#__PURE__*/React.createElement("ul", {
  className: "sc-bullets"
}, /*#__PURE__*/React.createElement("li", null, "S\xE9curisez votre activit\xE9 avec un cadre l\xE9gal pro"), /*#__PURE__*/React.createElement("li", null, "Rendez votre carri\xE8re durable et structur\xE9e"), /*#__PURE__*/React.createElement("li", null, "B\xE9n\xE9ficiez d'une protection sociale compl\xE8te")))));
window.PromiseSection = PromiseSection;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/PromiseSection.jsx", error: String((e && e.message) || e) }); }

})();
