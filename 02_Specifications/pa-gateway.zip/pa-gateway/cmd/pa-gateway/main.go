// Commande pa-gateway : passerelle entre Stairling Enterprise et SuperPDP.
// Un seul binaire : API interne HTTP + workers de la file de jobs + garde-fou
// de planification. PostgreSQL porte les données, la file et les verrous.
package main

import (
	"context"
	"database/sql"
	"errors"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	_ "github.com/lib/pq" // ou github.com/jackc/pgx/v5/stdlib : le code n'utilise que database/sql

	"github.com/stairling/pa-gateway/internal/config"
	"github.com/stairling/pa-gateway/internal/emission"
	"github.com/stairling/pa-gateway/internal/enrollment"
	"github.com/stairling/pa-gateway/internal/httpapi"
	"github.com/stairling/pa-gateway/internal/logx"
	"github.com/stairling/pa-gateway/internal/queue"
	"github.com/stairling/pa-gateway/internal/reception"
	"github.com/stairling/pa-gateway/internal/secret"
	"github.com/stairling/pa-gateway/internal/store"
	"github.com/stairling/pa-gateway/internal/superpdp"
	"github.com/stairling/pa-gateway/internal/tokens"
	"github.com/stairling/pa-gateway/internal/tracking"
	"github.com/stairling/pa-gateway/internal/vault"
	"github.com/stairling/pa-gateway/migrations"
)

func main() {
	log := logx.New(os.Stdout)
	cfg, err := config.Load()
	if err != nil {
		log.Error("config", "error", err.Error())
		os.Exit(1)
	}
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	db, err := sql.Open("postgres", cfg.DatabaseURL)
	if err != nil {
		log.Error("db", "error", err.Error())
		os.Exit(1)
	}
	db.SetMaxOpenConns(20)
	if err := migrations.Apply(ctx, db); err != nil {
		log.Error("migrations", "error", err.Error())
		os.Exit(1)
	}

	sealer, err := secret.NewSealer(cfg.TokenEncKey)
	if err != nil {
		log.Error("sealer", "error", err.Error())
		os.Exit(1)
	}
	api := superpdp.New(cfg.SuperPDPBaseURL, cfg.ClientID, cfg.ClientSecret, cfg.RateLimitPerSecond)
	tok := &tokens.Source{DB: db, API: api, Sealer: sealer}

	enroll := &enrollment.Service{DB: db, API: api, Tokens: tok, Sealer: sealer, Log: log,
		RedirectURI: cfg.RedirectURI, NumberScheme: cfg.CompanyNumberScheme, SyncInterval: cfg.SyncInterval}
	emit := &emission.Service{DB: db, Tokens: tok, Log: log}
	coll := &reception.Collector{DB: db, Tokens: tok, Vault: vault.FS{Root: cfg.VaultDir}, Log: log}
	syncer := &tracking.Syncer{DB: db, Tokens: tok, Collector: coll, Log: log, Interval: cfg.SyncInterval}

	worker := &queue.Worker{
		DB: db, Log: log, Concurrency: cfg.Workers,
		Handlers: map[string]queue.Handler{
			"send":     emit.HandleSend,
			"payment":  emit.HandlePayment,
			"sync":     syncer.HandleSync,
			"decision": coll.HandleDecision,
		},
	}
	go worker.Run(ctx)
	go guard(ctx, db, cfg.SyncInterval, log)

	srv := &http.Server{
		Addr: cfg.ListenAddr,
		Handler: (&httpapi.API{Enroll: enroll, Emission: emit, Collector: coll, Log: log,
			Token: cfg.InternalAPIToken, AppReturnURL: cfg.AppReturnURL}).Routes(),
		ReadHeaderTimeout: 10 * time.Second,
	}
	go func() {
		<-ctx.Done()
		sctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		_ = srv.Shutdown(sctx)
	}()
	log.Info("start", "event", "http.listen", "outcome", cfg.ListenAddr)
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Error("http", "error", err.Error())
		os.Exit(1)
	}
}

// guard vérifie toutes les 5 minutes que chaque tenant raccordé a bien un job
// de synchro actif (rattrape une chaîne rompue, un redéploiement, etc.).
func guard(ctx context.Context, db *sql.DB, interval time.Duration, log interface {
	Warn(string, ...any)
}) {
	t := time.NewTicker(5 * time.Minute)
	defer t.Stop()
	for {
		ids, err := store.ConnectedTenants(ctx, db)
		if err == nil {
			for _, id := range ids {
				if err := tracking.EnsureScheduled(ctx, db, id, interval); err != nil {
					log.Warn("guard", "tenant_id", id, "error", err.Error())
				}
			}
		}
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
	}
}
