module github.com/stairling/pa-gateway

go 1.22.2

require github.com/lib/pq v1.10.9 // indirect
