// Tests d'intégration : vrai PostgreSQL + faux SuperPDP (internal/fakepdp).
// Lancer avec : TEST_DATABASE_URL=postgres://… go test ./integration/ -v
package integration

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"

	_ "github.com/lib/pq"

	"github.com/stairling/pa-gateway/internal/emission"
	"github.com/stairling/pa-gateway/internal/eninvoice"
	"github.com/stairling/pa-gateway/internal/enrollment"
	"github.com/stairling/pa-gateway/internal/fakepdp"
	"github.com/stairling/pa-gateway/internal/httpapi"
	"github.com/stairling/pa-gateway/internal/logx"
	"github.com/stairling/pa-gateway/internal/queue"
	"github.com/stairling/pa-gateway/internal/reception"
	"github.com/stairling/pa-gateway/internal/secret"
	"github.com/stairling/pa-gateway/internal/store"
	"github.com/stairling/pa-gateway/internal/superpdp"
	"github.com/stairling/pa-gateway/internal/tokens"
	"github.com/stairling/pa-gateway/internal/tracking"
	"github.com/stairling/pa-gateway/internal/vault"
	"github.com/stairling/pa-gateway/migrations"
)

type env struct {
	t      *testing.T
	ctx    context.Context
	db     *sql.DB
	fake   *fakepdp.Server
	tok    *tokens.Source
	enroll *enrollment.Service
	emit   *emission.Service
	coll   *reception.Collector
	worker *queue.Worker
	vault  string
	log    *slog.Logger
}

func setup(t *testing.T) *env {
	t.Helper()
	dsn := os.Getenv("TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("TEST_DATABASE_URL non défini")
	}
	ctx := context.Background()
	db, err := sql.Open("postgres", dsn)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { db.Close() })
	_, _ = db.Exec(`DROP TABLE IF EXISTS pa_jobs, pa_cursors, pa_events, pa_inbound, pa_status_history,
		pa_outbound, pa_oauth_requests, pa_connections CASCADE`)
	if err := migrations.Apply(ctx, db); err != nil {
		t.Fatal(err)
	}
	fake := fakepdp.New()
	t.Cleanup(fake.Close)

	log := logx.New(io.Discard)
	if os.Getenv("PA_TEST_LOG") != "" {
		log = logx.New(os.Stderr)
	}
	sealer, _ := secret.NewSealer(bytes.Repeat([]byte{7}, 32))
	api := superpdp.New(fake.URL, "cid", "csecret", 1000)
	tok := &tokens.Source{DB: db, API: api, Sealer: sealer}
	vdir := t.TempDir()
	e := &env{t: t, ctx: ctx, db: db, fake: fake, tok: tok, vault: vdir, log: log,
		enroll: &enrollment.Service{DB: db, API: api, Tokens: tok, Sealer: sealer, Log: log,
			RedirectURI: "https://app.test/oauth/callback", NumberScheme: "sandbox", SyncInterval: time.Hour},
		emit: &emission.Service{DB: db, Tokens: tok, Log: log},
		coll: &reception.Collector{DB: db, Tokens: tok, Vault: vault.FS{Root: vdir}, Log: log},
	}
	syncer := &tracking.Syncer{DB: db, Tokens: tok, Collector: e.coll, Log: log, Interval: time.Hour}
	e.worker = &queue.Worker{DB: db, Log: log, Handlers: map[string]queue.Handler{
		"send": e.emit.HandleSend, "payment": e.emit.HandlePayment,
		"sync": syncer.HandleSync, "decision": e.coll.HandleDecision,
	}}
	return e
}

// connect déroule le vrai flux d'enrôlement jusqu'au callback.
func (e *env) connect(tenantID int64) string {
	e.t.Helper()
	u, err := e.enroll.Start(e.ctx, tenantID, "73282932000074", "gerant@demo.fr")
	if err != nil {
		e.t.Fatal(err)
	}
	parsed, _ := url.Parse(u)
	_, state, err := e.enroll.Callback(e.ctx, "good-code", parsed.Query().Get("state"), "")
	if err != nil {
		e.t.Fatal(err)
	}
	return state
}

func (e *env) enable(tenantID int64, emissionFrom, receptionFrom string) {
	e.t.Helper()
	var em, rc *time.Time
	if emissionFrom != "" {
		d, _ := time.Parse("2006-01-02", emissionFrom)
		em = &d
	}
	if receptionFrom != "" {
		d, _ := time.Parse("2006-01-02", receptionFrom)
		rc = &d
	}
	if err := store.SetEnablement(e.ctx, e.db, tenantID, em, rc); err != nil {
		e.t.Fatal(err)
	}
}

// drain exécute tous les jobs dus maintenant.
func (e *env) drain() int {
	e.t.Helper()
	n := 0
	for i := 0; i < 50; i++ {
		worked, err := e.worker.RunOne(e.ctx)
		if err != nil {
			e.t.Fatal(err)
		}
		if !worked {
			return n
		}
		n++
	}
	e.t.Fatal("drain : trop de jobs, boucle ?")
	return n
}

func (e *env) makeDue() {
	_, _ = e.db.Exec(`UPDATE pa_jobs SET run_at=now() WHERE state='available'`)
}

func (e *env) scalar(q string, args ...any) any {
	e.t.Helper()
	var v any
	if err := e.db.QueryRow(q, args...).Scan(&v); err != nil {
		e.t.Fatalf("%s: %v", q, err)
	}
	return v
}

// ---------------------------------------------------------------------------

func TestEnrollment(t *testing.T) {
	e := setup(t)

	if _, err := e.enroll.Start(e.ctx, 1, "123", "gerant@demo.fr"); !errors.Is(err, enrollment.ErrInvalidSIRET) {
		t.Fatalf("SIRET invalide accepté : %v", err)
	}

	u, err := e.enroll.Start(e.ctx, 1, "73282932000074", "gerant@demo.fr")
	if err != nil {
		t.Fatal(err)
	}
	q, _ := url.Parse(u)
	if q.Query().Get("superpdp_company_number") != "732829320" || q.Query().Get("code_challenge") == "" {
		t.Fatalf("URL d'autorisation incomplète : %s", u)
	}
	state := q.Query().Get("state")

	_, st, err := e.enroll.Callback(e.ctx, "good-code", state, "")
	if err != nil || st != "connected" {
		t.Fatalf("callback : %s %v", st, err)
	}
	// Le state est à usage unique.
	if _, _, err := e.enroll.Callback(e.ctx, "good-code", state, ""); !errors.Is(err, store.ErrStateInvalid) {
		t.Fatalf("state rejoué accepté : %v", err)
	}
	// Raccordé → une synchro est planifiée, et company_id est connu.
	if n := e.scalar(`SELECT count(*) FROM pa_jobs WHERE kind='sync' AND tenant_id=1`); n.(int64) != 1 {
		t.Fatalf("jobs sync = %v", n)
	}
	if id := e.scalar(`SELECT company_id FROM pa_connections WHERE tenant_id=1`); id.(int64) != 77 {
		t.Fatalf("company_id = %v", id)
	}
}

func TestEnrollmentPendingThenVerified(t *testing.T) {
	e := setup(t)
	e.fake.Lock()
	e.fake.KYB = "needs_review"
	e.fake.Unlock()
	if st := e.connect(2); st != "pending_verification" {
		t.Fatalf("état = %s", st)
	}
	// Émission bloquée tant que le KYB n'est pas vérifié.
	if _, _, err := e.tok.Client(e.ctx, 2); !errors.Is(err, tokens.ErrPendingVerification) {
		t.Fatalf("client obtenu en pending : %v", err)
	}
	e.fake.Lock()
	e.fake.KYB = "verified"
	e.fake.Unlock()
	if st, err := e.enroll.Verify(e.ctx, 2); err != nil || st != "connected" {
		t.Fatalf("Verify : %s %v", st, err)
	}
}

func TestDeniedConsent(t *testing.T) {
	e := setup(t)
	u, _ := e.enroll.Start(e.ctx, 3, "73282932000074", "gerant@demo.fr")
	q, _ := url.Parse(u)
	if _, _, err := e.enroll.Callback(e.ctx, "", q.Query().Get("state"), "access_denied"); !errors.Is(err, enrollment.ErrDenied) {
		t.Fatalf("refus non détecté : %v", err)
	}
}

func TestRefreshIsSerializedAndRotationPersisted(t *testing.T) {
	e := setup(t)
	e.connect(1)
	_, _ = e.db.Exec(`UPDATE pa_connections SET expires_at = now() - interval '1 minute'`)

	var wg sync.WaitGroup
	results := make([]string, 10)
	errs := make([]error, 10)
	for i := range results {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			results[i], errs[i] = e.tok.Fresh(e.ctx, 1)
		}(i)
	}
	wg.Wait()
	for i := range results {
		if errs[i] != nil || results[i] != results[0] {
			t.Fatalf("worker %d : %q %v (attendu %q)", i, results[i], errs[i], results[0])
		}
	}
	if e.fake.RefreshCalls != 1 {
		t.Fatalf("%d refresh au lieu d'1 : la rotation aurait cassé la connexion", e.fake.RefreshCalls)
	}

	// Refresh token révoqué → reconnect_required, persisté.
	_, _ = e.db.Exec(`UPDATE pa_connections SET expires_at = now() - interval '1 minute'`)
	e.fake.ExpireAccessTokens()
	_, _ = e.db.Exec(`UPDATE pa_connections SET refresh_token_enc = access_token_enc`) // jeton inconnu du serveur
	if _, err := e.tok.Fresh(e.ctx, 1); !errors.Is(err, tokens.ErrReconnectRequired) {
		t.Fatalf("invalid_grant non traduit : %v", err)
	}
	if st := e.scalar(`SELECT state FROM pa_connections WHERE tenant_id=1`); st.(string) != "reconnect_required" {
		t.Fatalf("état = %v", st)
	}
}

func TestEmissionHappyPathAndIdempotence(t *testing.T) {
	e := setup(t)
	e.connect(1)
	e.enable(1, "2026-09-01", "")

	// Hors périmètre : facture antérieure à l'ouverture.
	old := eninvoice.Sample()
	old.IssueDate = "2026-08-31"
	if _, _, err := e.emit.Submit(e.ctx, 1, "FA-OLD", old); !errors.Is(err, emission.ErrOutOfScope) {
		t.Fatalf("hors périmètre accepté : %v", err)
	}

	id, findings, err := e.emit.Submit(e.ctx, 1, "FA-2026-0042", eninvoice.Sample())
	if err != nil || len(findings) != 0 {
		t.Fatalf("submit : %v %v", err, findings)
	}
	e.drain()

	out, _ := store.GetOutbound(e.ctx, e.db, id)
	if !out.PDPInvoiceID.Valid || out.StatusCode.Int64 != 200 || out.Nature.Valid {
		t.Fatalf("après envoi : %+v", out)
	}
	if n := e.scalar(`SELECT count(*) FROM pa_status_history WHERE outbound_id=$1`, id); n.(int64) != 1 {
		t.Fatalf("historique = %v lignes", n)
	}
	// Une facture transmise ne repart jamais.
	if _, _, err := e.emit.Submit(e.ctx, 1, "FA-2026-0042", eninvoice.Sample()); !errors.Is(err, store.ErrAlreadyTransmitted) {
		t.Fatalf("resoumission d'une facture transmise : %v", err)
	}
}

func TestEmissionFailureNatures(t *testing.T) {
	e := setup(t)
	e.connect(1)
	e.enable(1, "2026-01-01", "")
	_, _ = e.db.Exec(`DELETE FROM pa_jobs WHERE kind='sync'`)

	// 1. Rejet de contenu : compté, retry différé.
	e.fake.Lock()
	e.fake.UploadStatus, e.fake.UploadBody = 400, `{"errors":["[BR-FR-05] BT-22","PEPPOL-EN16931-R008"]}`
	e.fake.Unlock()
	id, _, _ := e.emit.Submit(e.ctx, 1, "FA-1", eninvoice.Sample())
	e.drain()
	out, _ := store.GetOutbound(e.ctx, e.db, id)
	if out.Nature.String != "refused" || out.Attempts != 1 {
		t.Fatalf("refus : nature=%s attempts=%d", out.Nature.String, out.Attempts)
	}

	// 2. Panne transitoire : NE compte PAS.
	e.fake.Lock()
	e.fake.UploadStatus, e.fake.UploadBody = 503, "oops"
	e.fake.Unlock()
	e.makeDue()
	e.drain()
	out, _ = store.GetOutbound(e.ctx, e.db, id)
	if out.Nature.String != "failed" || out.Attempts != 1 {
		t.Fatalf("transitoire : nature=%s attempts=%d", out.Nature.String, out.Attempts)
	}

	// 3. Rejets répétés : plafond de 5 → exhausted, job abandonné.
	e.fake.Lock()
	e.fake.UploadStatus = 400
	e.fake.Unlock()
	for i := 0; i < 6; i++ {
		e.makeDue()
		e.drain()
	}
	out, _ = store.GetOutbound(e.ctx, e.db, id)
	if out.Nature.String != "exhausted" || out.Attempts != 5 {
		t.Fatalf("plafond : nature=%s attempts=%d", out.Nature.String, out.Attempts)
	}
	if st := e.scalar(`SELECT state FROM pa_jobs WHERE kind='send'`); st.(string) != "discarded" {
		t.Fatalf("job send = %v", st)
	}

	// 4. Resoumission corrigée : compteur remis à zéro, la facture part.
	e.fake.Lock()
	e.fake.UploadStatus = 0
	e.fake.Unlock()
	if _, _, err := e.emit.Submit(e.ctx, 1, "FA-1", eninvoice.Sample()); err != nil {
		t.Fatal(err)
	}
	e.drain()
	out, _ = store.GetOutbound(e.ctx, e.db, id)
	if !out.PDPInvoiceID.Valid || out.Attempts != 0 {
		t.Fatalf("après resoumission : %+v", out)
	}
}

func TestInvalidInvoiceIsHeldUntilCorrected(t *testing.T) {
	e := setup(t)
	e.connect(1)
	e.enable(1, "2026-01-01", "")
	bad := eninvoice.Sample()
	bad.Notes = nil
	id, findings, err := e.emit.Submit(e.ctx, 1, "FA-2", bad)
	if err != nil || !eninvoice.HasBlocking(findings) {
		t.Fatalf("submit : %v %v", err, findings)
	}
	e.drain()
	out, _ := store.GetOutbound(e.ctx, e.db, id)
	if out.Nature.String != "invalid" || out.PDPInvoiceID.Valid {
		t.Fatalf("facture invalide partie : %+v", out)
	}
	if _, _, err := e.emit.Submit(e.ctx, 1, "FA-2", eninvoice.Sample()); err != nil {
		t.Fatal(err)
	}
	e.drain()
	out, _ = store.GetOutbound(e.ctx, e.db, id)
	if !out.PDPInvoiceID.Valid {
		t.Fatalf("facture corrigée non partie : %+v", out)
	}
}

func TestSyncReceptionAndTracking(t *testing.T) {
	e := setup(t)
	e.connect(1)
	e.enable(1, "2026-01-01", "2026-01-01")

	// Une facture émise, qui recevra « Encaissée » par la passe événements.
	id, _, _ := e.emit.Submit(e.ctx, 1, "FA-3", eninvoice.Sample())
	e.drain()
	out, _ := store.GetOutbound(e.ctx, e.db, id)

	e.fake.Lock()
	// Identifiants choisis pour piéger un curseur lexicographique ("9" > "100").
	for _, fid := range []int64{9, 10, 100} {
		e.fake.Incoming = append(e.fake.Incoming, map[string]any{"id": fid, "direction": "in",
			"en_invoice": map[string]any{"number": "F-" + string(rune('A'+fid%26))}})
		e.fake.Natives[fid] = []byte("%PDF natif " + string(rune('A'+fid%26)))
	}
	e.fake.Events = append(e.fake.Events,
		map[string]any{"id": 5001, "invoice_id": 9, "status_code": "api:received"},
		map[string]any{"id": 5002, "invoice_id": out.PDPInvoiceID.Int64, "status_code": "fr:212"},
		map[string]any{"id": 5003, "invoice_id": out.PDPInvoiceID.Int64, "status_code": "x:inconnu"},
	)
	e.fake.Unlock()

	e.makeDue()
	e.drain()

	if n := e.scalar(`SELECT count(*) FROM pa_inbound WHERE detail IS NOT NULL AND native_sha256 IS NOT NULL`); n.(int64) != 3 {
		t.Fatalf("factures reçues complètes = %v", n)
	}
	if c, _ := store.GetCursor(e.ctx, e.db, 1, "invoices_in"); c != 100 {
		t.Fatalf("curseur factures = %d (attendu 100)", c)
	}
	if c, _ := store.GetCursor(e.ctx, e.db, 1, "events"); c != 5003 {
		t.Fatalf("curseur événements = %d", c)
	}
	files, _ := filepath.Glob(filepath.Join(e.vault, "tenant-1", "inbound", "*"))
	if len(files) != 3 {
		t.Fatalf("coffre : %d fichiers", len(files))
	}
	out, _ = store.GetOutbound(e.ctx, e.db, id)
	if out.StatusCode.Int64 != 212 {
		t.Fatalf("statut émis = %d (attendu 212)", out.StatusCode.Int64)
	}
	// Le code inconnu est conservé brut sans écraser 212.
	if n := e.scalar(`SELECT count(*) FROM pa_status_history WHERE outbound_id=$1 AND raw_code='x:inconnu' AND status_code IS NULL`, id); n.(int64) != 1 {
		t.Fatalf("code inconnu non historisé : %v", n)
	}
	// La synchro s'est replanifiée pour plus tard.
	if n := e.scalar(`SELECT count(*) FROM pa_jobs WHERE kind='sync' AND state='available' AND run_at > now() + interval '50 minutes'`); n.(int64) != 1 {
		t.Fatalf("synchro suivante = %v", n)
	}

	// Deuxième passage : aucun doublon.
	e.makeDue()
	e.drain()
	if n := e.scalar(`SELECT count(*) FROM pa_inbound`); n.(int64) != 3 {
		t.Fatalf("doublons en réception : %v", n)
	}
}

func TestReceptionOffStillIngestsEvents(t *testing.T) {
	e := setup(t)
	e.connect(1)
	e.enable(1, "2026-01-01", "") // réception coupée
	id, _, _ := e.emit.Submit(e.ctx, 1, "FA-4", eninvoice.Sample())
	e.drain()
	out, _ := store.GetOutbound(e.ctx, e.db, id)
	e.fake.Lock()
	e.fake.Incoming = append(e.fake.Incoming, map[string]any{"id": 42, "direction": "in"})
	e.fake.Events = append(e.fake.Events, map[string]any{"id": 6001, "invoice_id": out.PDPInvoiceID.Int64,
		"status_code": "fr:210", "data": map[string]any{"reason": "prix non conforme"}})
	e.fake.Unlock()
	e.makeDue()
	e.drain()
	if n := e.scalar(`SELECT count(*) FROM pa_inbound`); n.(int64) != 0 {
		t.Fatal("réception coupée mais factures ingérées")
	}
	if r := e.scalar(`SELECT reason FROM pa_status_history WHERE outbound_id=$1 AND status_code=210`, id); r.(string) != "prix non conforme" {
		t.Fatalf("refus non ingéré : %v", r)
	}
}

func TestPaymentAndDecision(t *testing.T) {
	e := setup(t)
	e.connect(1)
	e.enable(1, "2026-01-01", "2026-01-01")
	id, _, _ := e.emit.Submit(e.ctx, 1, "FA-5", eninvoice.Sample())
	e.drain()

	_, _ = queue.Enqueue(e.ctx, e.db, "payment", 1, emission.PaymentArgs{OutboundID: id, Amount: "1226.16"}, queue.EnqueueOpts{})
	e.fake.Lock()
	e.fake.Incoming = append(e.fake.Incoming, map[string]any{"id": 77})
	e.fake.Unlock()
	e.makeDue()
	e.drain()
	out, _ := store.GetOutbound(e.ctx, e.db, id)
	if out.StatusCode.Int64 != 212 {
		t.Fatalf("encaissement non déclaré : %d", out.StatusCode.Int64)
	}

	if err := e.coll.Decide(e.ctx, 1, reception.DecisionArgs{PDPInvoiceID: 77, Decision: "refused"}); !errors.Is(err, reception.ErrReasonRequired) {
		t.Fatalf("refus sans motif accepté : %v", err)
	}
	if err := e.coll.Decide(e.ctx, 1, reception.DecisionArgs{PDPInvoiceID: 77, Decision: "refused", ReasonCode: "PRIX"}); err != nil {
		t.Fatal(err)
	}
	e.drain()
	e.fake.Lock()
	defer e.fake.Unlock()
	codes := map[string]bool{}
	for _, ev := range e.fake.CreatedEvents {
		codes[ev["status_code"].(string)] = true
	}
	if !codes["fr:212"] || !codes["fr:210"] {
		t.Fatalf("événements envoyés : %v", e.fake.CreatedEvents)
	}
	if sent := e.scalar(`SELECT decision_sent FROM pa_inbound WHERE pdp_invoice_id=77`); sent.(bool) != true {
		t.Fatal("décision non marquée envoyée")
	}
}

func TestHTTPAPI(t *testing.T) {
	e := setup(t)
	api := &httpapi.API{Enroll: e.enroll, Emission: e.emit, Collector: e.coll, Log: e.log, Token: "s3cret"}
	srv := httptest.NewServer(api.Routes())
	defer srv.Close()

	do := func(method, path, token string, body any) *http.Response {
		var rd io.Reader
		if body != nil {
			b, _ := json.Marshal(body)
			rd = bytes.NewReader(b)
		}
		req, _ := http.NewRequest(method, srv.URL+path, rd)
		if token != "" {
			req.Header.Set("Authorization", "Bearer "+token)
		}
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatal(err)
		}
		return resp
	}

	if r := do("GET", "/v1/tenants/1/connection", "", nil); r.StatusCode != 401 {
		t.Fatalf("sans jeton : %d", r.StatusCode)
	}
	r := do("POST", "/v1/tenants/1/connection/authorize", "s3cret", map[string]string{"siret": "73282932000074", "login_email": "g@demo.fr"})
	var auth map[string]string
	_ = json.NewDecoder(r.Body).Decode(&auth)
	u, _ := url.Parse(auth["authorize_url"])

	// Le navigateur revient sur le callback public.
	cb, _ := http.Get(srv.URL + "/oauth/callback?code=good-code&state=" + url.QueryEscape(u.Query().Get("state")))
	var res map[string][]string
	_ = json.NewDecoder(cb.Body).Decode(&res)
	if res["result"][0] != "connected" {
		t.Fatalf("callback HTTP : %v", res)
	}

	do("PUT", "/v1/tenants/1/connection/enablement", "s3cret", map[string]any{"emission_enabled_from": "2026-01-01"})
	r = do("POST", "/v1/tenants/1/invoices", "s3cret", map[string]any{"external_id": "FA-HTTP", "invoice": eninvoice.Sample()})
	if r.StatusCode != 202 {
		b, _ := io.ReadAll(r.Body)
		t.Fatalf("soumission : %d %s", r.StatusCode, b)
	}
	e.drain()
	r = do("GET", "/v1/tenants/1/invoices/FA-HTTP", "s3cret", nil)
	var st map[string]any
	_ = json.NewDecoder(r.Body).Decode(&st)
	if st["status_code"].(float64) != 200 {
		t.Fatalf("statut HTTP : %v", st)
	}
}
