// Package config lit la configuration depuis l'environnement.
package config

import (
	"encoding/base64"
	"fmt"
	"os"
	"time"
)

type Config struct {
	DatabaseURL string
	ListenAddr  string

	SuperPDPBaseURL     string // https://api.superpdp.tech (sandbox et prod : c'est le compte qui change)
	ClientID            string
	ClientSecret        string
	RedirectURI         string // déclarée au caractère près chez SuperPDP, sans slash final
	CompanyNumberScheme string // fr_siren en prod, sandbox en test
	TokenEncKey         []byte // 32 octets, AES-256-GCM ; stable dans le temps
	InternalAPIToken    string // secret partagé avec Stairling Enterprise
	AppReturnURL        string // où renvoyer l'utilisateur après le callback OAuth
	VaultDir            string // coffre local (dev) ; S3 en prod via vault.Store
	SyncInterval        time.Duration
	Workers             int
	RateLimitPerSecond  int
}

func Load() (*Config, error) {
	c := &Config{
		DatabaseURL:         os.Getenv("DATABASE_URL"),
		ListenAddr:          getenv("LISTEN_ADDR", ":8080"),
		SuperPDPBaseURL:     getenv("SUPERPDP_BASE_URL", "https://api.superpdp.tech"),
		ClientID:            os.Getenv("SUPERPDP_CLIENT_ID"),
		ClientSecret:        os.Getenv("SUPERPDP_CLIENT_SECRET"),
		RedirectURI:         os.Getenv("SUPERPDP_REDIRECT_URI"),
		CompanyNumberScheme: getenv("SUPERPDP_COMPANY_NUMBER_SCHEME", "fr_siren"),
		InternalAPIToken:    os.Getenv("PA_INTERNAL_API_TOKEN"),
		AppReturnURL:        os.Getenv("PA_APP_RETURN_URL"),
		VaultDir:            getenv("PA_VAULT_DIR", "./vault"),
		SyncInterval:        time.Hour,
		Workers:             4,
		RateLimitPerSecond:  20, // l'éditeur annonce 30/s par clé : on garde une marge
	}
	key, err := base64.StdEncoding.DecodeString(os.Getenv("SUPERPDP_TOKEN_ENC_KEY"))
	if err != nil || len(key) != 32 {
		return nil, fmt.Errorf("SUPERPDP_TOKEN_ENC_KEY doit être 32 octets encodés en base64")
	}
	c.TokenEncKey = key
	for name, v := range map[string]string{
		"DATABASE_URL": c.DatabaseURL, "SUPERPDP_CLIENT_ID": c.ClientID,
		"SUPERPDP_CLIENT_SECRET": c.ClientSecret, "SUPERPDP_REDIRECT_URI": c.RedirectURI,
		"PA_INTERNAL_API_TOKEN": c.InternalAPIToken,
	} {
		if v == "" {
			return nil, fmt.Errorf("variable %s manquante", name)
		}
	}
	return c, nil
}

func getenv(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}
