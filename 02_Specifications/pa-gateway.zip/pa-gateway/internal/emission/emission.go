// Package emission contient les jobs d'émission : dépôt d'une facture
// (kind "send") et déclaration d'encaissement fr:212 (kind "payment").
//
// Invariants :
//   - par tenant : jeton et état de raccordement du tenant ;
//   - idempotent : une facture qui a un pdp_invoice_id ne repart jamais ;
//   - traçable : chaque statut crée une ligne d'historique avec la réponse brute.
//
// Natures d'échec et reprise :
//
//	invalid  contrôle local KO        compte (plafond 5)  → job annulé ; resoumission = relance
//	refused  400/422 + règles BR-*    compte (plafond 5)  → retry avec backoff
//	blocked  401/403/KYB/reconnexion  ne compte pas       → snooze 1 h
//	failed   5xx, timeout, TLS        ne compte pas       → snooze croissant, sans limite
//	exhausted plafond atteint          —                   → annulé ; resoumettre pour relancer
package emission

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"strings"
	"time"

	"github.com/stairling/pa-gateway/internal/eninvoice"
	"github.com/stairling/pa-gateway/internal/queue"
	"github.com/stairling/pa-gateway/internal/store"
	"github.com/stairling/pa-gateway/internal/superpdp"
	"github.com/stairling/pa-gateway/internal/tokens"
)

const MaxDeterministicAttempts = 5

var ErrOutOfScope = errors.New("facture hors périmètre : émission non activée à sa date")

type SendArgs struct {
	OutboundID int64 `json:"outbound_id"`
}

type PaymentArgs struct {
	OutboundID int64  `json:"outbound_id"`
	Amount     string `json:"amount"` // montant encaissé
	PaidAt     string `json:"paid_at,omitempty"`
}

type Service struct {
	DB     *sql.DB
	Tokens *tokens.Source
	Log    *slog.Logger
}

// Submit enregistre la facture et met le job en file, atomiquement.
func (s *Service) Submit(ctx context.Context, tenantID int64, externalID string, inv *eninvoice.Invoice) (int64, []eninvoice.Finding, error) {
	findings := eninvoice.Validate(inv)
	issue, err := time.Parse("2006-01-02", inv.IssueDate)
	if err != nil {
		return 0, findings, fmt.Errorf("BT-2 illisible: %w", err)
	}
	conn, err := store.GetConnection(ctx, s.DB, tenantID)
	if errors.Is(err, store.ErrNotFound) {
		return 0, findings, tokens.ErrNotConnected
	}
	if err != nil {
		return 0, findings, err
	}
	if !InScope(conn, issue) {
		return 0, findings, ErrOutOfScope
	}
	payload, _ := json.Marshal(inv)
	var id int64
	err = store.WithTx(ctx, s.DB, func(tx *sql.Tx) error {
		var err error
		if id, err = store.SubmitOutbound(ctx, tx, tenantID, externalID, payload, issue); err != nil {
			return err
		}
		_, err = queue.Enqueue(ctx, tx, "send", tenantID, SendArgs{OutboundID: id},
			queue.EnqueueOpts{UniqueKey: fmt.Sprintf("send:%d", id), MaxAttempts: 1000})
		return err
	})
	return id, findings, err
}

// InScope : raccordé n'est pas transmettre. Il faut une date d'ouverture et
// une facture datée à partir de cette date.
func InScope(c *store.Connection, issueDate time.Time) bool {
	return c.EmissionEnabledFrom.Valid && !issueDate.Before(c.EmissionEnabledFrom.Time)
}

// HandleSend est le handler du job "send".
func (s *Service) HandleSend(ctx context.Context, job *queue.Job) error {
	var a SendArgs
	if err := job.Decode(&a); err != nil {
		return queue.Cancel(err)
	}
	out, err := store.GetOutbound(ctx, s.DB, a.OutboundID)
	if err != nil {
		return queue.Cancel(err)
	}
	log := s.Log.With("flow", "send", "tenant_id", out.TenantID, "outbound_id", out.ID, "external_id", out.ExternalID)

	if out.PDPInvoiceID.Valid { // idempotence
		return nil
	}

	// 1. Contrôle local — sur la version COURANTE du payload.
	var inv eninvoice.Invoice
	if err := json.Unmarshal(out.Payload, &inv); err != nil {
		return s.deterministic(ctx, log, out, "invalid", "payload illisible: "+err.Error(), false)
	}
	if fs := eninvoice.Validate(&inv); eninvoice.HasBlocking(fs) {
		msgs := make([]string, 0, len(fs))
		for _, f := range fs {
			if f.Level == eninvoice.Blocking {
				msgs = append(msgs, f.Rule+" "+f.Term)
			}
		}
		log.Warn("send", "event", "send.validate.ko", "rules", strings.Join(msgs, ","))
		return s.deterministic(ctx, log, out, "invalid", "À compléter avant transmission : "+strings.Join(msgs, ", "), false)
	}

	// 2. Raccordement, périmètre et jeton frais.
	api, conn, err := s.Tokens.Client(ctx, out.TenantID)
	if err != nil {
		return s.classify(ctx, log, out, err)
	}
	if !InScope(conn, out.IssueDate) {
		log.Info("send", "event", "send.out_of_scope")
		return queue.Cancel(ErrOutOfScope)
	}

	// 3. Conversion en Factur-X par la plateforme, puis dépôt.
	enJSON, err := eninvoice.ToSuperPDP(&inv)
	if err != nil {
		return s.deterministic(ctx, log, out, "invalid", err.Error(), false)
	}
	start := time.Now()
	pdf, err := api.Convert(ctx, enJSON)
	if err != nil {
		return s.classify(ctx, log, out, err)
	}
	created, err := api.Upload(ctx, pdf, "application/pdf", out.ExternalID)
	if err != nil {
		return s.classify(ctx, log, out, err)
	}

	// 4. Persistance immédiate : identifiant plateforme + premier statut.
	raw, _ := json.Marshal(created)
	code, ev, known := superpdp.LatestKnownStatus(created.Events)
	rawCode := ev.StatusCode
	if !known {
		code, rawCode = 200, "api:uploaded"
	}
	err = store.WithTx(ctx, s.DB, func(tx *sql.Tx) error {
		if err := store.MarkTransmitted(ctx, tx, out.ID, created.ID); err != nil {
			return err
		}
		_, err := store.RecordStatus(ctx, tx, out.ID, &code, rawCode, ev.Reason(), raw)
		return err
	})
	if err != nil {
		// Le dépôt a réussi mais pas l'écriture : NE PAS renvoyer à l'aveugle,
		// la plateforme répondrait « facture déjà existante ». On journalise
		// l'identifiant pour un rapprochement, et on retente uniquement l'écriture.
		log.Error("send", "event", "send.persist.ko", "pdp_invoice_id", created.ID, "error", err.Error())
		return err
	}
	log.Info("send", "event", "send.upload", "outcome", "ok", "pdp_invoice_id", created.ID,
		"status_code", code, "dur_ms", time.Since(start).Milliseconds())
	return nil
}

// classify range une erreur dans sa nature et décide de la reprise.
func (s *Service) classify(ctx context.Context, log *slog.Logger, out *store.Outbound, err error) error {
	var rej *superpdp.RejectedError
	var tr *superpdp.TransientError
	switch {
	case errors.Is(err, tokens.ErrPendingVerification), errors.Is(err, tokens.ErrReconnectRequired),
		errors.Is(err, tokens.ErrNotConnected), errors.Is(err, superpdp.ErrUnauthorized),
		errors.Is(err, superpdp.ErrForbidden), errors.Is(err, superpdp.ErrInvalidGrant):
		_, _ = store.MarkFailure(ctx, s.DB, out.ID, "blocked", err.Error(), false)
		log.Warn("send", "event", "send.blocked", "nature", "blocked", "error", err.Error())
		return queue.Snooze(time.Hour, err)
	case errors.As(err, &rej):
		msg := err.Error()
		if strings.Contains(strings.ToLower(rej.Body), "existante") {
			msg = "doublon côté plateforme (même contenu déjà déposé) : rapprochement manuel"
		}
		log.Warn("send", "event", "send.refused", "nature", "refused", "http", rej.Status, "rules", strings.Join(rej.Rules, ","))
		return s.deterministic(ctx, log, out, "refused", msg, true)
	case errors.As(err, &tr), errors.Is(err, context.DeadlineExceeded):
		_, _ = store.MarkFailure(ctx, s.DB, out.ID, "failed", err.Error(), false)
		log.Warn("send", "event", "send.failed.transmission", "nature", "failed", "error", err.Error())
		return queue.Snooze(queue.DefaultBackoff(1+out.Attempts), err)
	default:
		_, _ = store.MarkFailure(ctx, s.DB, out.ID, "failed", err.Error(), false)
		return err
	}
}

// deterministic compte la tentative ; au plafond, la facture passe « exhausted ».
func (s *Service) deterministic(ctx context.Context, log *slog.Logger, out *store.Outbound, nature, msg string, retry bool) error {
	attempts, err := store.MarkFailure(ctx, s.DB, out.ID, nature, msg, true)
	if err != nil {
		return err
	}
	if attempts >= MaxDeterministicAttempts {
		_, _ = store.MarkFailure(ctx, s.DB, out.ID, "exhausted", msg, false)
		log.Error("send", "event", "send.exhausted", "nature", "exhausted", "attempt", attempts)
		return queue.Cancel(fmt.Errorf("plafond de %d tentatives atteint: %s", MaxDeterministicAttempts, msg))
	}
	if !retry {
		// Rien ne changera sans correction : la resoumission relancera le job.
		return queue.Cancel(errors.New(msg))
	}
	return fmt.Errorf("%s: %s", nature, msg) // retry compté, avec backoff
}

// HandlePayment déclare l'encaissement (fr:212). Idempotent et rejouable.
func (s *Service) HandlePayment(ctx context.Context, job *queue.Job) error {
	var a PaymentArgs
	if err := job.Decode(&a); err != nil {
		return queue.Cancel(err)
	}
	out, err := store.GetOutbound(ctx, s.DB, a.OutboundID)
	if err != nil {
		return queue.Cancel(err)
	}
	if !out.PDPInvoiceID.Valid {
		return queue.Snooze(time.Hour, errors.New("facture pas encore transmise"))
	}
	if out.StatusCode.Valid && out.StatusCode.Int64 == 212 {
		return nil // déjà déclarée
	}
	api, _, err := s.Tokens.Client(ctx, out.TenantID)
	if err != nil {
		return queue.Snooze(time.Hour, err)
	}
	details := map[string]any{"amount": a.Amount}
	if a.PaidAt != "" {
		details["date"] = a.PaidAt
	}
	ev, err := api.CreateEvent(ctx, superpdp.NewEvent{InvoiceID: out.PDPInvoiceID.Int64, StatusCode: "fr:212", Details: details})
	var tr *superpdp.TransientError
	switch {
	case err == nil:
	case errors.As(err, &tr):
		return queue.Snooze(15*time.Minute, err)
	case errors.Is(err, superpdp.ErrUnauthorized), errors.Is(err, superpdp.ErrForbidden):
		return queue.Snooze(time.Hour, err)
	default:
		return err
	}
	raw, _ := json.Marshal(ev)
	code := 212
	_, err = store.RecordStatus(ctx, s.DB, out.ID, &code, "fr:212", "", raw)
	s.Log.Info("send", "flow", "send", "event", "payment.sent", "tenant_id", out.TenantID, "outbound_id", out.ID)
	return err
}
