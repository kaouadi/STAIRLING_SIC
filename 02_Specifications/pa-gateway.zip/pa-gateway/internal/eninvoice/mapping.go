package eninvoice

import "encoding/json"

// ToSuperPDP traduit le modèle interne en JSON « en_invoice » pour
// POST /v1.beta/invoices/convert?from=en16931&to=factur-x.
//
// ⚠ SEUL FICHIER À ALIGNER SUR LA SPEC. Les noms de clés ci-dessous suivent
// ceux observés dans les clients communautaires (number, issue_date,
// currency_code, seller.legal_registration_identifier, electronic_address…)
// mais n'ont pas été vérifiés contre le schéma en_invoice de l'OpenAPI
// SuperPDP. Procédure : télécharger la spec (api.superpdp.tech/openapi/…),
// générer les types avec oapi-codegen, remplacer les map[string]any par ces
// types, et valider un aller-retour en bac à sable (pdp_sandbox:send_payload).
//
// Deux choix de fond sont en revanche acquis et à conserver :
//   - BG-13 (livraison) est toujours émis, date de facture par défaut :
//     un bloc vide produit PEPPOL-EN16931-R008, qui rejette ;
//   - les mentions PMD / PMT / AAB partent en notes codées (BR-FR-05).
func ToSuperPDP(inv *Invoice) (json.RawMessage, error) {
	notes := make([]map[string]any, 0, len(inv.Notes))
	for _, n := range inv.Notes {
		notes = append(notes, omitEmpty(map[string]any{"note": n.Text, "subject_code": n.SubjectCode}))
	}
	lines := make([]map[string]any, 0, len(inv.Lines))
	for _, l := range inv.Lines {
		lines = append(lines, map[string]any{
			"identifier":             l.ID,
			"name":                   l.Name,
			"invoiced_quantity":      l.Quantity,
			"invoiced_quantity_code": l.UnitCode,
			"net_price":              l.NetPrice,
			"net_amount":             l.NetAmount,
			"vat_category_code":      l.VATCategory,
			"vat_rate":               l.VATRate,
		})
	}
	vat := make([]map[string]any, 0, len(inv.VAT))
	for _, b := range inv.VAT {
		vat = append(vat, omitEmpty(map[string]any{
			"vat_category_code":           b.Category,
			"vat_category_rate":           b.Rate,
			"vat_category_taxable_amount": b.TaxableAmount,
			"vat_category_tax_amount":     b.TaxAmount,
			"vat_exemption_reason_text":   b.ExemptionReason,
		}))
	}

	deliveryDate := inv.IssueDate
	var deliveryAddr any
	if inv.Delivery != nil {
		if inv.Delivery.Date != "" {
			deliveryDate = inv.Delivery.Date
		}
		if inv.Delivery.Address != nil {
			deliveryAddr = address(inv.Delivery.Address)
		}
	}

	doc := omitEmpty(map[string]any{
		"number":                   inv.Number,
		"issue_date":               inv.IssueDate,
		"type_code":                inv.TypeCode,
		"currency_code":            inv.Currency,
		"payment_due_date":         inv.DueDate,
		"buyer_reference":          inv.BuyerReference,
		"purchase_order_reference": inv.PurchaseOrderRef,
		"process_control": map[string]any{
			"business_process_type": inv.BusinessProcess, // BT-23
		},
		"notes":  notes,
		"seller": party(inv.Seller),
		"buyer":  party(inv.Buyer),
		"delivery_information": omitEmpty(map[string]any{
			"actual_delivery_date": deliveryDate,
			"delivery_address":     deliveryAddr,
		}),
		"lines":         lines,
		"vat_breakdown": vat,
		"totals": map[string]any{
			"sum_invoice_lines_amount": inv.Totals.LineTotal,
			"total_without_vat":        inv.Totals.TaxExclusive,
			"total_vat_amount":         inv.Totals.TaxTotal,
			"total_with_vat":           inv.Totals.TaxInclusive,
			"amount_due_for_payment":   inv.Totals.Payable,
		},
	})
	if inv.Preceding != nil {
		doc["preceding_invoice_reference"] = []any{omitEmpty(map[string]any{
			"reference": inv.Preceding.Number, "issue_date": inv.Preceding.IssueDate, "type_code": inv.Preceding.TypeCode,
		})}
	}
	if p := inv.Payment; p != nil {
		doc["payment_instructions"] = omitEmpty(map[string]any{
			"payment_means_type_code": p.MeansCode,
			"remittance_information":  p.Reference,
			"credit_transfers": []any{omitEmpty(map[string]any{
				"account_identifier": p.IBAN, "service_provider_identifier": p.BIC,
			})},
		})
	}
	return json.Marshal(doc)
}

func party(p Party) map[string]any {
	m := omitEmpty(map[string]any{
		"name":                          p.Name,
		"vat_identifier":                p.VATID,
		"legal_registration_identifier": map[string]any{"scheme": "0002", "value": p.SIREN},
	})
	if p.ElectronicAddress != nil {
		m["electronic_address"] = map[string]any{"scheme": p.ElectronicAddress.Scheme, "value": p.ElectronicAddress.Value}
	}
	if p.Address != nil {
		m["postal_address"] = address(p.Address)
	}
	return m
}

func address(a *PostalAddress) map[string]any {
	return omitEmpty(map[string]any{
		"address_line1": a.Line1, "city": a.City, "post_code": a.PostCode, "country_code": a.Country,
	})
}

func omitEmpty(m map[string]any) map[string]any {
	for k, v := range m {
		switch x := v.(type) {
		case nil:
			delete(m, k)
		case string:
			if x == "" {
				delete(m, k)
			}
		case map[string]any:
			if len(x) == 0 {
				delete(m, k)
			}
		}
	}
	return m
}
