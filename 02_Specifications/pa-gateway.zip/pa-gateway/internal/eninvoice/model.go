// Package eninvoice porte le modèle de facture EN 16931 tel que Stairling
// Enterprise le soumet à la passerelle, son validateur local, et sa
// traduction vers le JSON en_invoice attendu par SuperPDP (mapping.go).
//
// Les montants sont des chaînes décimales ("1234.50") : jamais de float64.
// Chaque champ indique son terme métier (BT/BG) : ce sont ces codes que
// citent les rejets de la plateforme.
package eninvoice

type Invoice struct {
	Number           string         `json:"number"`                       // BT-1
	IssueDate        string         `json:"issue_date"`                   // BT-2, AAAA-MM-JJ
	TypeCode         string         `json:"type_code"`                    // BT-3 : 380, 381, 384, 386, 389
	Currency         string         `json:"currency"`                     // BT-5
	DueDate          string         `json:"due_date,omitempty"`           // BT-9
	BuyerReference   string         `json:"buyer_reference,omitempty"`    // BT-10
	PurchaseOrderRef string         `json:"purchase_order_ref,omitempty"` // BT-13
	BusinessProcess  string         `json:"business_process"`             // BT-23 : cadre de facturation (S1, B1, M1…)
	Preceding        *Preceding     `json:"preceding,omitempty"`          // BG-3 : obligatoire sur 381 / 384
	Notes            []Note         `json:"notes"`                        // BG-1 : mentions PMD, PMT, AAB
	Seller           Party          `json:"seller"`                       // BG-4
	Buyer            Party          `json:"buyer"`                        // BG-7
	Delivery         *Delivery      `json:"delivery,omitempty"`           // BG-13
	Payment          *Payment       `json:"payment,omitempty"`            // BG-16
	Lines            []Line         `json:"lines"`                        // BG-25
	VAT              []VATBreakdown `json:"vat_breakdown"`                // BG-23
	Totals           Totals         `json:"totals"`                       // BG-22
}

type Preceding struct {
	Number    string `json:"number"`               // BT-25
	IssueDate string `json:"issue_date,omitempty"` // BT-26
	TypeCode  string `json:"type_code,omitempty"`  // type du document précédent (règle FR)
}

type Note struct {
	SubjectCode string `json:"subject_code,omitempty"` // BT-21 : PMD, PMT, AAB…
	Text        string `json:"text"`                   // BT-22
}

type Party struct {
	Name              string         `json:"name"`                         // BT-27 / BT-44
	SIREN             string         `json:"siren"`                        // BT-30 / BT-47, schéma 0002
	VATID             string         `json:"vat_id,omitempty"`             // BT-31 / BT-48
	ElectronicAddress *EAddress      `json:"electronic_address,omitempty"` // BT-34 / BT-49
	Address           *PostalAddress `json:"address,omitempty"`            // BG-5 / BG-8
}

// EAddress : adresse de routage. Côté acheteur, elle est LUE dans l'annuaire,
// jamais calculée.
type EAddress struct {
	Scheme string `json:"scheme"` // 0225 en France
	Value  string `json:"value"`  // SIREN, SIREN_SIRET ou SIREN_SIRET_CODE
}

type PostalAddress struct {
	Line1    string `json:"line1,omitempty"`
	City     string `json:"city,omitempty"`
	PostCode string `json:"post_code,omitempty"`
	Country  string `json:"country"` // BT-40 / BT-55
}

type Delivery struct {
	Date    string         `json:"date,omitempty"`    // BT-72
	Address *PostalAddress `json:"address,omitempty"` // BG-15, obligatoire si différente de l'acheteur
}

type Payment struct {
	MeansCode string `json:"means_code,omitempty"` // BT-81 (58 = virement SEPA)
	Reference string `json:"reference,omitempty"`  // BT-83
	IBAN      string `json:"iban,omitempty"`       // BT-84
	BIC       string `json:"bic,omitempty"`        // BT-86
}

type Line struct {
	ID          string `json:"id"`           // BT-126
	Name        string `json:"name"`         // BT-153
	Quantity    string `json:"quantity"`     // BT-129
	UnitCode    string `json:"unit_code"`    // BT-130 (C62 = unité)
	NetPrice    string `json:"net_price"`    // BT-146
	NetAmount   string `json:"net_amount"`   // BT-131
	VATCategory string `json:"vat_category"` // BT-151 : S, Z, E, AE, K, G, O
	VATRate     string `json:"vat_rate"`     // BT-152
}

type VATBreakdown struct {
	Category        string `json:"category"`                   // BT-118
	Rate            string `json:"rate"`                       // BT-119
	TaxableAmount   string `json:"taxable_amount"`             // BT-116
	TaxAmount       string `json:"tax_amount"`                 // BT-117
	ExemptionReason string `json:"exemption_reason,omitempty"` // BT-120
}

type Totals struct {
	LineTotal    string `json:"line_total"`    // BT-106
	TaxExclusive string `json:"tax_exclusive"` // BT-109
	TaxTotal     string `json:"tax_total"`     // BT-110
	TaxInclusive string `json:"tax_inclusive"` // BT-112
	Payable      string `json:"payable"`       // BT-115
}
