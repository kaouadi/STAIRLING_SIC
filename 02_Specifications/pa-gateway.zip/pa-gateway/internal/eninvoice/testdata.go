package eninvoice

// Sample renvoie une facture de prestation conforme, utilisée par les tests.
func Sample() *Invoice {
	return &Invoice{
		Number: "FA-2026-0042", IssueDate: "2026-09-24", TypeCode: "380", Currency: "EUR",
		DueDate: "2026-10-24", PurchaseOrderRef: "BC-778", BusinessProcess: "S1",
		Notes: []Note{
			{SubjectCode: "PMD", Text: "Pénalités de retard : 3 fois le taux d'intérêt légal"},
			{SubjectCode: "PMT", Text: "Indemnité forfaitaire pour frais de recouvrement : 40 €"},
			{SubjectCode: "AAB", Text: "Escompte pour paiement anticipé : néant"},
		},
		Seller: Party{Name: "Stairling Démo SAS", SIREN: "732829320", VATID: "FR44732829320",
			ElectronicAddress: &EAddress{Scheme: "0225", Value: "732829320"},
			Address:           &PostalAddress{Line1: "1 rue de la Paix", City: "Paris", PostCode: "75002", Country: "FR"}},
		Buyer: Party{Name: "Client Exemple SARL", SIREN: "552100554",
			ElectronicAddress: &EAddress{Scheme: "0225", Value: "552100554"},
			Address:           &PostalAddress{City: "Lyon", PostCode: "69002", Country: "FR"}},
		Payment: &Payment{MeansCode: "58", Reference: "FA-2026-0042", IBAN: "FR7630006000011234567890189"},
		Lines: []Line{
			{ID: "1", Name: "Conseil", Quantity: "10", UnitCode: "HUR", NetPrice: "95.00", NetAmount: "950.00", VATCategory: "S", VATRate: "20"},
			{ID: "2", Name: "Déplacement", Quantity: "1.5", UnitCode: "C62", NetPrice: "33.333", NetAmount: "50.00", VATCategory: "S", VATRate: "20"},
			{ID: "3", Name: "Ouvrage", Quantity: "2", UnitCode: "C62", NetPrice: "12.40", NetAmount: "24.80", VATCategory: "S", VATRate: "5.5"},
		},
		VAT: []VATBreakdown{
			{Category: "S", Rate: "20", TaxableAmount: "1000.00", TaxAmount: "200.00"},
			{Category: "S", Rate: "5.5", TaxableAmount: "24.80", TaxAmount: "1.36"},
		},
		Totals: Totals{LineTotal: "1024.80", TaxExclusive: "1024.80", TaxTotal: "201.36", TaxInclusive: "1226.16", Payable: "1226.16"},
	}
}
