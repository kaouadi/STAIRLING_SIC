package eninvoice

import (
	"fmt"
	"math/big"
	"regexp"
	"sort"
	"strings"
	"time"
)

// Level : Blocking = la facture ne part pas ; Risk = elle part, mais une règle
// de la plateforme risque de la rejeter.
type Level string

const (
	Blocking Level = "blocking"
	Risk     Level = "risk"
)

// Finding cite les mêmes codes que la plateforme (BT et règle) pour que le
// message affiché à l'utilisateur soit le même avant et après envoi.
type Finding struct {
	Level   Level  `json:"level"`
	Rule    string `json:"rule"`
	Term    string `json:"term"`
	Message string `json:"message"`
}

func (f Finding) String() string {
	return fmt.Sprintf("[%s] %s %s : %s", f.Level, f.Rule, f.Term, f.Message)
}

var (
	sirenRe = regexp.MustCompile(`^\d{9}$`)
	dateFmt = "2006-01-02"
)

var validTypeCodes = map[string]bool{"380": true, "381": true, "384": true, "386": true, "389": true}
var exemptCategories = map[string]bool{"E": true, "AE": true, "K": true, "G": true, "O": true}

// Validate applique les contrôles locaux. Il ne remplace pas la validation
// Schematron de la plateforme : il évite les allers-retours sur les causes connues.
func Validate(inv *Invoice) []Finding {
	v := &validator{}

	// ---- En-tête
	v.required(inv.Number, "BR-02", "BT-1", "numéro de facture")
	v.date(inv.IssueDate, "BR-03", "BT-2", "date d'émission", true)
	if !validTypeCodes[inv.TypeCode] {
		v.add(Blocking, "BR-04", "BT-3", "type de document attendu : 380, 381, 384, 386 ou 389")
	}
	v.required(inv.Currency, "BR-05", "BT-5", "devise")
	v.date(inv.DueDate, "BR-CO-25", "BT-9", "date d'échéance", false)
	if strings.TrimSpace(inv.BusinessProcess) == "" {
		v.add(Blocking, "BR-FR-08", "BT-23", "cadre de facturation obligatoire (S1 prestation, B1 biens, M1 mixte…)")
	}
	if (inv.TypeCode == "381" || inv.TypeCode == "384") && (inv.Preceding == nil || inv.Preceding.Number == "") {
		v.add(Blocking, "BR-FR", "BT-25", "un avoir ou une facture rectificative doit citer la facture d'origine")
	}

	// ---- Mentions françaises (BR-FR-05) : les trois, en notes codées
	have := map[string]bool{}
	for _, n := range inv.Notes {
		if strings.TrimSpace(n.Text) != "" {
			have[n.SubjectCode] = true
		}
	}
	for code, label := range map[string]string{
		"PMD": "taux des pénalités de retard",
		"PMT": "indemnité forfaitaire de recouvrement (40 €)",
		"AAB": "conditions d'escompte (ou « néant »)",
	} {
		if !have[code] {
			v.add(Blocking, "BR-FR-05", "BT-22", fmt.Sprintf("mention obligatoire manquante (%s) : %s", code, label))
		}
	}

	// ---- Parties
	v.party(inv.Seller, "vendeur", "BT-27", "BT-30", "BT-34", false)
	v.party(inv.Buyer, "acheteur", "BT-44", "BT-47", "BT-49", true)

	// ---- Lignes et calculs (BR-CO)
	if len(inv.Lines) == 0 {
		v.add(Blocking, "BR-16", "BG-25", "au moins une ligne de facture")
	}
	lineSum := new(big.Rat)
	perRate := map[string]*big.Rat{} // clé catégorie|taux
	for i, l := range inv.Lines {
		ref := fmt.Sprintf("ligne %d", i+1)
		v.required(l.Name, "BR-25", "BT-153", ref+" : désignation")
		v.required(l.UnitCode, "BR-23", "BT-130", ref+" : unité")
		v.required(l.VATCategory, "BR-CO-04", "BT-151", ref+" : catégorie de TVA")
		qty, ok1 := v.num(l.Quantity, "BT-129", ref+" : quantité")
		price, ok2 := v.num(l.NetPrice, "BT-146", ref+" : prix net")
		net, ok3 := v.num(l.NetAmount, "BT-131", ref+" : montant net")
		if ok1 && ok2 && ok3 {
			want := Round2(new(big.Rat).Mul(qty, price))
			if want.Cmp(net) != 0 {
				v.add(Blocking, "BR-CO-LINE", "BT-131", fmt.Sprintf("%s : quantité × prix = %s, montant déclaré %s",
					ref, want.FloatString(2), net.FloatString(2)))
			}
		}
		if ok3 {
			lineSum.Add(lineSum, net)
			k := l.VATCategory + "|" + normRate(l.VATRate)
			if perRate[k] == nil {
				perRate[k] = new(big.Rat)
			}
			perRate[k].Add(perRate[k], net)
		}
	}

	t := inv.Totals
	bt106, ok106 := v.num(t.LineTotal, "BT-106", "total des lignes")
	bt109, ok109 := v.num(t.TaxExclusive, "BT-109", "total HT")
	bt110, ok110 := v.num(t.TaxTotal, "BT-110", "total TVA")
	bt112, ok112 := v.num(t.TaxInclusive, "BT-112", "total TTC")
	bt115, ok115 := v.num(t.Payable, "BT-115", "net à payer")

	if ok106 && bt106.Cmp(lineSum) != 0 {
		v.add(Blocking, "BR-CO-10", "BT-106", fmt.Sprintf("somme des lignes = %s, total déclaré %s",
			lineSum.FloatString(2), bt106.FloatString(2)))
	}
	// Ce modèle ne porte pas de remises/frais de document : BT-109 = BT-106.
	if ok106 && ok109 && bt109.Cmp(bt106) != 0 {
		v.add(Blocking, "BR-CO-13", "BT-109", "total HT différent du total des lignes (remises/frais non gérés ici)")
	}
	if ok109 && ok110 && ok112 {
		if s := new(big.Rat).Add(bt109, bt110); s.Cmp(bt112) != 0 {
			v.add(Blocking, "BR-CO-15", "BT-112", fmt.Sprintf("HT + TVA = %s, TTC déclaré %s", s.FloatString(2), bt112.FloatString(2)))
		}
	}
	if ok112 && ok115 && bt112.Cmp(bt115) != 0 {
		v.add(Risk, "BR-CO-16", "BT-115", "net à payer différent du TTC : acompte (BT-113) non géré par ce modèle")
	}

	// ---- Ventilation TVA (BG-23)
	vatSum := new(big.Rat)
	seen := map[string]bool{}
	for i, b := range inv.VAT {
		ref := fmt.Sprintf("ventilation %d (%s %s%%)", i+1, b.Category, b.Rate)
		k := b.Category + "|" + normRate(b.Rate)
		seen[k] = true
		base, okb := v.num(b.TaxableAmount, "BT-116", ref+" : base")
		tax, okt := v.num(b.TaxAmount, "BT-117", ref+" : montant")
		rate, okr := v.num(b.Rate, "BT-119", ref+" : taux")
		if okb && perRate[k] != nil && perRate[k].Cmp(base) != 0 {
			v.add(Blocking, "BR-CO-17", "BT-116", fmt.Sprintf("%s : base = %s selon les lignes", ref, perRate[k].FloatString(2)))
		}
		if okb && okt && okr {
			want := Round2(new(big.Rat).Quo(new(big.Rat).Mul(base, rate), big.NewRat(100, 1)))
			if want.Cmp(tax) != 0 {
				v.add(Blocking, "BR-CO-17", "BT-117", fmt.Sprintf("%s : base × taux = %s", ref, want.FloatString(2)))
			}
		}
		if okt {
			vatSum.Add(vatSum, tax)
		}
		if exemptCategories[b.Category] && strings.TrimSpace(b.ExemptionReason) == "" {
			v.add(Blocking, "BR-"+b.Category+"-10", "BT-120", ref+" : motif d'exonération obligatoire")
		}
	}
	for k := range perRate {
		if !seen[k] {
			v.add(Blocking, "BR-CO-18", "BG-23", "catégorie/taux présent sur les lignes sans ventilation TVA : "+k)
		}
	}
	if ok110 && vatSum.Cmp(bt110) != 0 {
		v.add(Blocking, "BR-CO-14", "BT-110", fmt.Sprintf("somme des TVA ventilées = %s, total TVA déclaré %s",
			vatSum.FloatString(2), bt110.FloatString(2)))
	}

	sort.SliceStable(v.out, func(i, j int) bool { return v.out[i].Level == Blocking && v.out[j].Level != Blocking })
	return v.out
}

// HasBlocking indique si la facture ne doit pas partir.
func HasBlocking(fs []Finding) bool {
	for _, f := range fs {
		if f.Level == Blocking {
			return true
		}
	}
	return false
}

// Round2 arrondit au centime, demi au-dessus (en valeur absolue).
func Round2(r *big.Rat) *big.Rat {
	num := new(big.Int).Mul(r.Num(), big.NewInt(100))
	den := r.Denom()
	q, m := new(big.Int).QuoRem(num, den, new(big.Int))
	twice := new(big.Int).Mul(new(big.Int).Abs(m), big.NewInt(2))
	if twice.Cmp(den) >= 0 {
		if num.Sign() < 0 {
			q.Sub(q, big.NewInt(1))
		} else {
			q.Add(q, big.NewInt(1))
		}
	}
	return new(big.Rat).SetFrac(q, big.NewInt(100))
}

func normRate(s string) string {
	r, ok := new(big.Rat).SetString(strings.TrimSpace(s))
	if !ok {
		return s
	}
	return r.FloatString(2)
}

type validator struct{ out []Finding }

func (v *validator) add(l Level, rule, term, msg string) {
	v.out = append(v.out, Finding{Level: l, Rule: rule, Term: term, Message: msg})
}

func (v *validator) required(s, rule, term, label string) {
	if strings.TrimSpace(s) == "" {
		v.add(Blocking, rule, term, label+" obligatoire")
	}
}

func (v *validator) date(s, rule, term, label string, required bool) {
	if s == "" {
		if required {
			v.add(Blocking, rule, term, label+" obligatoire")
		}
		return
	}
	if _, err := time.Parse(dateFmt, s); err != nil {
		v.add(Blocking, rule, term, label+" : format AAAA-MM-JJ attendu")
	}
}

func (v *validator) num(s, term, label string) (*big.Rat, bool) {
	r, ok := new(big.Rat).SetString(strings.TrimSpace(s))
	if !ok {
		v.add(Blocking, "FORMAT", term, label+" : nombre décimal attendu (ex. 1234.50)")
		return nil, false
	}
	return r, true
}

func (v *validator) party(p Party, who, nameBT, sirenBT, addrBT string, isBuyer bool) {
	v.required(p.Name, "BR-06", nameBT, "raison sociale du "+who)
	if !sirenRe.MatchString(p.SIREN) {
		rule := "BR-FR"
		if isBuyer {
			rule = "BR-FR (réforme)"
		}
		v.add(Blocking, rule, sirenBT, "SIREN du "+who+" : 9 chiffres attendus")
	}
	if p.ElectronicAddress == nil || p.ElectronicAddress.Value == "" || p.ElectronicAddress.Scheme == "" {
		level := Risk
		if isBuyer {
			level = Blocking // sans adresse de routage, la facture ne peut pas partir
		}
		v.add(level, "BR-62/63", addrBT, "adresse électronique du "+who+" (lue dans l'annuaire)")
	}
	if p.Address == nil || p.Address.Country == "" {
		v.add(Blocking, "BR-09/11", "BT-40/55", "pays de l'adresse du "+who)
	}
}
