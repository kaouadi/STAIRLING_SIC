package eninvoice

import (
	"encoding/json"
	"math/big"
	"strings"
	"testing"
)

func rules(fs []Finding) string {
	var s []string
	for _, f := range fs {
		s = append(s, f.Rule+"/"+f.Term)
	}
	return strings.Join(s, " ")
}

func TestSampleIsValid(t *testing.T) {
	if fs := Validate(Sample()); len(fs) != 0 {
		t.Fatalf("facture d'exemple non conforme : %v", fs)
	}
}

func TestFrenchMentionsAndProcess(t *testing.T) {
	inv := Sample()
	inv.Notes = inv.Notes[:1] // ne garde que PMD
	inv.BusinessProcess = ""
	got := rules(Validate(inv))
	for _, want := range []string{"BR-FR-05/BT-22", "BR-FR-08/BT-23"} {
		if !strings.Contains(got, want) {
			t.Errorf("%s absent de %s", want, got)
		}
	}
	if strings.Count(got, "BR-FR-05") != 2 {
		t.Errorf("attendu 2 mentions manquantes (PMT, AAB) : %s", got)
	}
}

func TestTotalsCoherence(t *testing.T) {
	inv := Sample()
	inv.Totals.LineTotal = "1024.81"
	inv.VAT[1].TaxAmount = "1.37"
	got := rules(Validate(inv))
	for _, want := range []string{"BR-CO-10", "BR-CO-17/BT-117", "BR-CO-14"} {
		if !strings.Contains(got, want) {
			t.Errorf("%s absent de %s", want, got)
		}
	}
}

func TestCreditNoteNeedsPreceding(t *testing.T) {
	inv := Sample()
	inv.TypeCode = "381"
	if !strings.Contains(rules(Validate(inv)), "BT-25") {
		t.Fatal("avoir sans facture d'origine accepté")
	}
}

func TestBuyerAddressBlocking(t *testing.T) {
	inv := Sample()
	inv.Buyer.ElectronicAddress = nil
	if !HasBlocking(Validate(inv)) {
		t.Fatal("acheteur sans adresse de routage non bloquant")
	}
}

func TestRound2(t *testing.T) {
	for in, want := range map[string]string{"49.9995": "50.00", "1.364": "1.36", "1.365": "1.37", "-1.365": "-1.37"} {
		r, _ := new(big.Rat).SetString(in)
		if got := Round2(r).FloatString(2); got != want {
			t.Errorf("Round2(%s) = %s, attendu %s", in, got, want)
		}
	}
}

func TestMappingAlwaysEmitsDelivery(t *testing.T) {
	raw, err := ToSuperPDP(Sample())
	if err != nil {
		t.Fatal(err)
	}
	var m map[string]any
	_ = json.Unmarshal(raw, &m)
	d, ok := m["delivery_information"].(map[string]any)
	if !ok || d["actual_delivery_date"] != "2026-09-24" {
		t.Fatalf("BG-13 absent ou sans date : %v", m["delivery_information"])
	}
}
