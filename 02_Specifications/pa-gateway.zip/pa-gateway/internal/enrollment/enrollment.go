// Package enrollment implémente le raccordement d'un tenant à SuperPDP
// (modèle multi-tenant : OAuth 2.1 Authorization Code + PKCE).
//
// Nous déclenchons le flux et lisons son résultat ; l'enrôlement lui-même
// (compte, gérant, justificatifs KYB) se passe chez SuperPDP.
//
//	disconnected ──consentement──▶ pending_verification ──KYB verified──▶ connected
//	      ▲                                                              │
//	      └────────── déconnexion ◀───── reconnect_required ◀──invalid_grant
package enrollment

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"log/slog"
	"net/mail"
	"time"

	"github.com/stairling/pa-gateway/internal/oauth"
	"github.com/stairling/pa-gateway/internal/secret"
	"github.com/stairling/pa-gateway/internal/store"
	"github.com/stairling/pa-gateway/internal/superpdp"
	"github.com/stairling/pa-gateway/internal/tokens"
	"github.com/stairling/pa-gateway/internal/tracking"
)

var (
	ErrInvalidSIRET = errors.New("SIRET absent ou invalide (14 chiffres attendus)")
	ErrInvalidEmail = errors.New("email de connexion SuperPDP absent ou invalide")
	ErrDenied       = errors.New("consentement refusé ou erreur du serveur d'autorisation")
)

type Service struct {
	DB           *sql.DB
	API          *superpdp.Client
	Tokens       *tokens.Source
	Sealer       *secret.Sealer
	Log          *slog.Logger
	RedirectURI  string
	NumberScheme string // fr_siren | sandbox
	SyncInterval time.Duration
}

// Start valide les prérequis, mémorise la demande et renvoie l'URL de consentement.
// Le serveur refait le contrôle : ne jamais se fier au seul bouton désactivé.
func (s *Service) Start(ctx context.Context, tenantID int64, siret, loginEmail string) (string, error) {
	siren, ok := oauth.SIRENFromSIRET(siret)
	if !ok {
		return "", ErrInvalidSIRET
	}
	if _, err := mail.ParseAddress(loginEmail); err != nil {
		return "", ErrInvalidEmail
	}
	state := oauth.RandomToken(32)
	verifier := oauth.NewVerifier()
	vEnc, err := s.Sealer.Seal(verifier)
	if err != nil {
		return "", err
	}
	err = store.WithTx(ctx, s.DB, func(tx *sql.Tx) error {
		if err := store.UpsertIdentity(ctx, tx, tenantID, siren, loginEmail); err != nil {
			return err
		}
		return store.SaveOAuthRequest(ctx, tx, state, tenantID, vEnc)
	})
	if err != nil {
		return "", err
	}
	s.Log.Info("enroll", "flow", "enroll", "event", "authorize.start", "tenant_id", tenantID)
	return oauth.AuthorizeURL(oauth.AuthorizeParams{
		BaseURL: s.API.BaseURL, ClientID: s.API.ClientID, RedirectURI: s.RedirectURI,
		State: state, Verifier: verifier, LoginHint: loginEmail,
		SIREN: siren, NumberScheme: s.NumberScheme,
	}), nil
}

// Callback traite le retour de SuperPDP. Renvoie le tenant et son nouvel état.
func (s *Service) Callback(ctx context.Context, code, state, oauthError string) (int64, string, error) {
	// Le state est consommé même en cas de refus : usage unique.
	tenantID, vEnc, err := store.ConsumeOAuthRequest(ctx, s.DB, state)
	if err != nil {
		s.Log.Warn("enroll", "flow", "enroll", "event", "callback.state.ko")
		return 0, "", err
	}
	log := s.Log.With("flow", "enroll", "tenant_id", tenantID)
	if oauthError != "" || code == "" {
		log.Warn("enroll", "event", "callback.denied", "reason", oauthError)
		return tenantID, "", ErrDenied
	}
	verifier, err := s.Sealer.Open(vEnc)
	if err != nil {
		return tenantID, "", err
	}
	tok, err := s.API.ExchangeCode(ctx, code, verifier, s.RedirectURI)
	if err != nil {
		log.Error("enroll", "event", "token.exchange.ko", "error", err.Error())
		return tenantID, "", err
	}
	if err := s.Tokens.Save(ctx, s.DB, tenantID, tok); err != nil {
		return tenantID, "", err
	}
	// Au minimum pending_verification : le jeton existe, le KYB décidera.
	if err := store.SetState(ctx, s.DB, tenantID, "pending_verification", nil); err != nil {
		return tenantID, "", err
	}
	log.Info("enroll", "event", "token.exchange.ok")

	newState, err := s.applyVerification(ctx, tenantID, s.API.As(tok.AccessToken))
	if err != nil {
		// KYB illisible (réseau) : on reste en pending_verification, « Revérifier » relira.
		log.Warn("enroll", "event", "verify.ko", "error", err.Error())
		return tenantID, "pending_verification", nil
	}
	return tenantID, newState, nil
}

// Verify relit le statut KYB (bouton « Revérifier », ou avant l'émission).
func (s *Service) Verify(ctx context.Context, tenantID int64) (string, error) {
	conn, err := store.GetConnection(ctx, s.DB, tenantID)
	if err != nil {
		return "", err
	}
	if conn.State == "disconnected" || conn.State == "reconnect_required" {
		return conn.State, nil
	}
	tok, err := s.Tokens.Fresh(ctx, tenantID)
	if errors.Is(err, tokens.ErrReconnectRequired) {
		return "reconnect_required", nil
	}
	if err != nil {
		return conn.State, err
	}
	return s.applyVerification(ctx, tenantID, s.API.As(tok))
}

func (s *Service) applyVerification(ctx context.Context, tenantID int64, api *superpdp.Scoped) (string, error) {
	sess, err := api.SessionMe(ctx)
	if err != nil {
		return "", fmt.Errorf("oauth2_sessions/me: %w", err)
	}
	kyb := sess.CompanyVerificationStatus
	state := "pending_verification"
	if kyb == "verified" {
		state = "connected"
	}
	s.Log.Info("verify", "flow", "verify", "tenant_id", tenantID, "kyb_status", kyb, "state", state)
	err = store.WithTx(ctx, s.DB, func(tx *sql.Tx) error {
		if err := store.SetState(ctx, tx, tenantID, state, &kyb); err != nil {
			return err
		}
		if state == "connected" {
			// Planifie la synchro du tenant dès le raccordement.
			return tracking.EnsureScheduled(ctx, tx, tenantID, s.SyncInterval)
		}
		return nil
	})
	if err != nil {
		return "", err
	}
	if state == "connected" {
		if c, err := api.CompanyMe(ctx); err == nil && c.ID > 0 {
			_ = store.SetCompanyID(ctx, s.DB, tenantID, c.ID) // best-effort
		}
	}
	return state, nil
}
