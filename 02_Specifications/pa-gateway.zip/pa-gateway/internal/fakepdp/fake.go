// Package fakepdp simule l'API SuperPDP pour les tests d'intégration.
// Il reproduit les comportements qui comptent pour la passerelle :
// rotation du refresh token (l'ancien devient invalide), 403 tant que le KYB
// n'est pas vérifié, pagination à curseur, rejets 400 avec règles Schematron.
package fakepdp

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"sync"
)

type Server struct {
	*httptest.Server

	mu            sync.Mutex
	KYB           string          // verified | needs_review
	validRefresh  map[string]bool // refresh tokens encore utilisables
	validAccess   map[string]bool
	RefreshCalls  int
	nextID        int64
	Outgoing      map[int64]map[string]any
	Incoming      []map[string]any // factures reçues, id croissants
	Events        []map[string]any // événements, id croissants
	UploadStatus  int              // si ≠ 0 : statut forcé au dépôt
	UploadBody    string
	CreatedEvents []map[string]any
	Natives       map[int64][]byte
}

func New() *Server {
	s := &Server{
		KYB: "verified", validRefresh: map[string]bool{}, validAccess: map[string]bool{},
		nextID: 1000, Outgoing: map[int64]map[string]any{}, Natives: map[int64][]byte{},
	}
	s.Server = httptest.NewServer(http.HandlerFunc(s.handle))
	return s
}

func (s *Server) issue() map[string]any {
	s.nextID++
	a := fmt.Sprintf("at-%d", s.nextID)
	r := fmt.Sprintf("rt-%d", s.nextID)
	s.validAccess[a], s.validRefresh[r] = true, true
	return map[string]any{"access_token": a, "refresh_token": r, "expires_in": 1800, "token_type": "Bearer"}
}

// NewID renvoie un identifiant unique (factures, événements).
func (s *Server) NewID() int64 {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.nextID++
	return s.nextID
}

func (s *Server) handle(w http.ResponseWriter, r *http.Request) {
	s.mu.Lock()
	defer s.mu.Unlock()
	p := r.URL.Path

	if p == "/oauth2/token" {
		_ = r.ParseForm()
		switch r.Form.Get("grant_type") {
		case "authorization_code":
			if r.Form.Get("code") != "good-code" || r.Form.Get("code_verifier") == "" {
				writeJSON(w, 400, map[string]string{"error": "invalid_grant"})
				return
			}
		case "refresh_token":
			s.RefreshCalls++
			rt := r.Form.Get("refresh_token")
			if !s.validRefresh[rt] {
				writeJSON(w, 400, map[string]string{"error": "invalid_grant"})
				return
			}
			delete(s.validRefresh, rt) // rotation : l'ancien meurt
		}
		writeJSON(w, 200, s.issue())
		return
	}

	tok := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
	if !s.validAccess[tok] {
		w.WriteHeader(401)
		return
	}
	p = strings.TrimPrefix(p, "/v1.beta")
	if p == "/oauth2_sessions/me" {
		writeJSON(w, 200, map[string]string{"company_verification_status": s.KYB})
		return
	}
	if s.KYB != "verified" {
		w.WriteHeader(403)
		return
	}
	switch {
	case p == "/companies/me":
		writeJSON(w, 200, map[string]any{"id": 77, "name": "Démo SAS"})
	case p == "/invoices/convert" && r.Method == http.MethodPost:
		body, _ := io.ReadAll(r.Body)
		if !json.Valid(body) {
			writeJSON(w, 400, map[string]string{"message": "json invalide"})
			return
		}
		w.Header().Set("Content-Type", "application/pdf")
		_, _ = w.Write(append([]byte("%PDF-FAKE "), body[:min(len(body), 20)]...))
	case p == "/invoices" && r.Method == http.MethodPost:
		if s.UploadStatus != 0 {
			w.WriteHeader(s.UploadStatus)
			_, _ = w.Write([]byte(s.UploadBody))
			return
		}
		s.nextID++
		id := s.nextID
		ev := map[string]any{"id": s.nextID + 1, "invoice_id": id, "status_code": "api:uploaded"}
		s.nextID++
		inv := map[string]any{"id": id, "external_id": r.URL.Query().Get("external_id"), "events": []any{ev}}
		s.Outgoing[id] = inv
		writeJSON(w, 201, inv)
	case p == "/invoices" && r.Method == http.MethodGet:
		after, _ := strconv.ParseInt(r.URL.Query().Get("starting_after_id"), 10, 64)
		limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
		writeJSON(w, 200, map[string]any{"data": page(s.Incoming, after, limit)})
	case p == "/invoice_events" && r.Method == http.MethodGet:
		after, _ := strconv.ParseInt(r.URL.Query().Get("starting_after_id"), 10, 64)
		limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
		writeJSON(w, 200, map[string]any{"data": page(s.Events, after, limit)})
	case p == "/invoice_events" && r.Method == http.MethodPost:
		var e map[string]any
		_ = json.NewDecoder(r.Body).Decode(&e)
		s.nextID++
		e["id"] = s.nextID
		s.CreatedEvents = append(s.CreatedEvents, e)
		writeJSON(w, 201, e)
	case strings.HasSuffix(p, "/download"):
		id, _ := strconv.ParseInt(strings.TrimSuffix(strings.TrimPrefix(p, "/invoices/"), "/download"), 10, 64)
		_, _ = w.Write(s.Natives[id])
	case strings.HasPrefix(p, "/invoices/"):
		id, _ := strconv.ParseInt(strings.TrimPrefix(p, "/invoices/"), 10, 64)
		if inv, ok := s.Outgoing[id]; ok {
			writeJSON(w, 200, inv)
			return
		}
		for _, inv := range s.Incoming {
			if toInt(inv["id"]) == id {
				writeJSON(w, 200, inv)
				return
			}
		}
		w.WriteHeader(404)
	default:
		w.WriteHeader(404)
	}
}

// ExpireAccessTokens invalide tous les access tokens (simule leur expiration).
func (s *Server) ExpireAccessTokens() {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.validAccess = map[string]bool{}
}

// Lock / Unlock pour modifier l'état du faux serveur depuis un test.
func (s *Server) Lock()   { s.mu.Lock() }
func (s *Server) Unlock() { s.mu.Unlock() }

func page(items []map[string]any, after int64, limit int) []map[string]any {
	out := []map[string]any{}
	for _, it := range items {
		if toInt(it["id"]) > after {
			out = append(out, it)
			if limit > 0 && len(out) == limit {
				break
			}
		}
	}
	return out
}

func toInt(v any) int64 {
	switch x := v.(type) {
	case int64:
		return x
	case int:
		return int64(x)
	case float64:
		return int64(x)
	}
	return 0
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
