// Package httpapi expose l'API interne appelée par Stairling Enterprise,
// ainsi que le callback OAuth appelé par le navigateur de l'utilisateur.
//
//	GET  /v1/tenants/{id}/connection                      état du raccordement
//	POST /v1/tenants/{id}/connection/authorize            → URL de consentement
//	POST /v1/tenants/{id}/connection/verify               « Revérifier » (KYB)
//	PUT  /v1/tenants/{id}/connection/enablement           dates d'ouverture émission / réception
//	DELETE /v1/tenants/{id}/connection                    déconnexion
//	POST /v1/tenants/{id}/invoices                        soumettre une facture (202)
//	GET  /v1/tenants/{id}/invoices/{external_id}          statut + historique
//	POST /v1/tenants/{id}/invoices/{external_id}/payment  déclarer l'encaissement (fr:212)
//	GET  /v1/tenants/{id}/inbound?after=&limit=           factures reçues
//	POST /v1/tenants/{id}/inbound/{pdp_id}/decision       approuver / refuser
//	GET  /oauth/callback                                  retour SuperPDP (public)
package httpapi

import (
	"crypto/subtle"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"net/url"
	"strconv"
	"time"

	"github.com/stairling/pa-gateway/internal/emission"
	"github.com/stairling/pa-gateway/internal/eninvoice"
	"github.com/stairling/pa-gateway/internal/enrollment"
	"github.com/stairling/pa-gateway/internal/queue"
	"github.com/stairling/pa-gateway/internal/reception"
	"github.com/stairling/pa-gateway/internal/store"
	"github.com/stairling/pa-gateway/internal/tokens"
)

type API struct {
	Enroll       *enrollment.Service
	Emission     *emission.Service
	Collector    *reception.Collector
	Log          *slog.Logger
	Token        string // secret partagé avec Stairling Enterprise
	AppReturnURL string
}

func (a *API) Routes() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /oauth/callback", a.callback)

	priv := http.NewServeMux()
	priv.HandleFunc("GET /v1/tenants/{id}/connection", a.getConnection)
	priv.HandleFunc("POST /v1/tenants/{id}/connection/authorize", a.authorize)
	priv.HandleFunc("POST /v1/tenants/{id}/connection/verify", a.verify)
	priv.HandleFunc("PUT /v1/tenants/{id}/connection/enablement", a.enablement)
	priv.HandleFunc("DELETE /v1/tenants/{id}/connection", a.disconnect)
	priv.HandleFunc("POST /v1/tenants/{id}/invoices", a.submitInvoice)
	priv.HandleFunc("GET /v1/tenants/{id}/invoices/{ext}", a.getInvoice)
	priv.HandleFunc("POST /v1/tenants/{id}/invoices/{ext}/payment", a.payment)
	priv.HandleFunc("GET /v1/tenants/{id}/inbound", a.listInbound)
	priv.HandleFunc("POST /v1/tenants/{id}/inbound/{pdp}/decision", a.decision)
	mux.Handle("/v1/", a.auth(priv))
	return mux
}

func (a *API) auth(next http.Handler) http.Handler {
	want := []byte("Bearer " + a.Token)
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if subtle.ConstantTimeCompare([]byte(r.Header.Get("Authorization")), want) != 1 {
			writeErr(w, http.StatusUnauthorized, "unauthorized", "jeton interne invalide")
			return
		}
		next.ServeHTTP(w, r)
	})
}

// ---- Raccordement -----------------------------------------------------------

func (a *API) getConnection(w http.ResponseWriter, r *http.Request) {
	id, ok := tenant(w, r)
	if !ok {
		return
	}
	c, err := store.GetConnection(r.Context(), a.Enroll.DB, id)
	if errors.Is(err, store.ErrNotFound) {
		writeJSON(w, http.StatusOK, map[string]any{"state": "disconnected"})
		return
	}
	if err != nil {
		a.internal(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"state": c.State, "kyb_status": nullStr(c.KYBStatus), "siren": c.SIREN,
		"emission_enabled_from": nullDate(c.EmissionEnabledFrom), "reception_enabled_from": nullDate(c.ReceptionEnabledFrom),
	})
}

func (a *API) authorize(w http.ResponseWriter, r *http.Request) {
	id, ok := tenant(w, r)
	if !ok {
		return
	}
	var body struct {
		SIRET      string `json:"siret"`
		LoginEmail string `json:"login_email"`
	}
	if !readJSON(w, r, &body) {
		return
	}
	u, err := a.Enroll.Start(r.Context(), id, body.SIRET, body.LoginEmail)
	switch {
	case errors.Is(err, enrollment.ErrInvalidSIRET), errors.Is(err, enrollment.ErrInvalidEmail):
		writeErr(w, http.StatusUnprocessableEntity, "prerequisite", err.Error())
	case err != nil:
		a.internal(w, err)
	default:
		writeJSON(w, http.StatusOK, map[string]string{"authorize_url": u})
	}
}

func (a *API) callback(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	tenantID, state, err := a.Enroll.Callback(r.Context(), q.Get("code"), q.Get("state"), q.Get("error"))
	result := url.Values{}
	if tenantID != 0 {
		result.Set("tenant_id", strconv.FormatInt(tenantID, 10))
	}
	switch {
	case errors.Is(err, store.ErrStateInvalid):
		result.Set("result", "invalid_state")
	case errors.Is(err, enrollment.ErrDenied):
		result.Set("result", "denied")
	case err != nil:
		result.Set("result", "error")
	default:
		result.Set("result", state)
	}
	if a.AppReturnURL == "" {
		writeJSON(w, http.StatusOK, result)
		return
	}
	http.Redirect(w, r, a.AppReturnURL+"?"+result.Encode(), http.StatusFound)
}

func (a *API) verify(w http.ResponseWriter, r *http.Request) {
	id, ok := tenant(w, r)
	if !ok {
		return
	}
	state, err := a.Enroll.Verify(r.Context(), id)
	if err != nil && !errors.Is(err, store.ErrNotFound) {
		a.internal(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"state": state})
}

func (a *API) enablement(w http.ResponseWriter, r *http.Request) {
	id, ok := tenant(w, r)
	if !ok {
		return
	}
	var body struct {
		EmissionFrom  *string `json:"emission_enabled_from"`  // AAAA-MM-JJ ou null (coupé)
		ReceptionFrom *string `json:"reception_enabled_from"` // AAAA-MM-JJ ou null (coupé)
	}
	if !readJSON(w, r, &body) {
		return
	}
	e, err1 := parseDate(body.EmissionFrom)
	rc, err2 := parseDate(body.ReceptionFrom)
	if err := errors.Join(err1, err2); err != nil {
		writeErr(w, http.StatusUnprocessableEntity, "bad_date", err.Error())
		return
	}
	if err := store.SetEnablement(r.Context(), a.Enroll.DB, id, e, rc); err != nil {
		a.internal(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (a *API) disconnect(w http.ResponseWriter, r *http.Request) {
	id, ok := tenant(w, r)
	if !ok {
		return
	}
	if err := store.Disconnect(r.Context(), a.Enroll.DB, id); err != nil {
		a.internal(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// ---- Émission -------------------------------------------------------------------

func (a *API) submitInvoice(w http.ResponseWriter, r *http.Request) {
	id, ok := tenant(w, r)
	if !ok {
		return
	}
	var body struct {
		ExternalID string            `json:"external_id"`
		Invoice    eninvoice.Invoice `json:"invoice"`
	}
	if !readJSON(w, r, &body) {
		return
	}
	if body.ExternalID == "" {
		writeErr(w, http.StatusUnprocessableEntity, "external_id", "external_id obligatoire")
		return
	}
	outID, findings, err := a.Emission.Submit(r.Context(), id, body.ExternalID, &body.Invoice)
	switch {
	case errors.Is(err, store.ErrAlreadyTransmitted):
		writeErr(w, http.StatusConflict, "already_transmitted", err.Error())
	case errors.Is(err, emission.ErrOutOfScope):
		writeErr(w, http.StatusConflict, "out_of_scope", err.Error())
	case errors.Is(err, tokens.ErrNotConnected):
		writeErr(w, http.StatusConflict, "not_connected", err.Error())
	case err != nil:
		a.internal(w, err)
	default:
		// 202 : la facture est acceptée pour traitement, même si le contrôle local
		// relève des points bloquants — le job les enregistrera comme « invalid »
		// et la resoumission corrigée relancera l'envoi.
		writeJSON(w, http.StatusAccepted, map[string]any{
			"outbound_id": outID, "findings": findings, "will_send": !eninvoice.HasBlocking(findings),
		})
	}
}

func (a *API) getInvoice(w http.ResponseWriter, r *http.Request) {
	id, ok := tenant(w, r)
	if !ok {
		return
	}
	o, err := store.GetOutboundByExternal(r.Context(), a.Emission.DB, id, r.PathValue("ext"))
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, http.StatusNotFound, "not_found", "facture inconnue")
		return
	}
	if err != nil {
		a.internal(w, err)
		return
	}
	hist, err := store.History(r.Context(), a.Emission.DB, o.ID)
	if err != nil {
		a.internal(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"external_id": o.ExternalID, "pdp_invoice_id": nullInt(o.PDPInvoiceID),
		"status_code": nullInt(o.StatusCode), "nature": nullStr(o.Nature), "attempts": o.Attempts,
		"last_error": nullStr(o.LastError), "history": hist,
	})
}

func (a *API) payment(w http.ResponseWriter, r *http.Request) {
	id, ok := tenant(w, r)
	if !ok {
		return
	}
	var body struct {
		Amount string `json:"amount"`
		PaidAt string `json:"paid_at"`
	}
	if !readJSON(w, r, &body) {
		return
	}
	o, err := store.GetOutboundByExternal(r.Context(), a.Emission.DB, id, r.PathValue("ext"))
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, http.StatusNotFound, "not_found", "facture inconnue")
		return
	}
	if err != nil {
		a.internal(w, err)
		return
	}
	_, err = queue.Enqueue(r.Context(), a.Emission.DB, "payment", id,
		emission.PaymentArgs{OutboundID: o.ID, Amount: body.Amount, PaidAt: body.PaidAt},
		queue.EnqueueOpts{UniqueKey: fmt.Sprintf("payment:%d", o.ID)})
	if err != nil {
		a.internal(w, err)
		return
	}
	w.WriteHeader(http.StatusAccepted)
}

// ---- Réception -----------------------------------------------------------------

func (a *API) listInbound(w http.ResponseWriter, r *http.Request) {
	id, ok := tenant(w, r)
	if !ok {
		return
	}
	after, _ := strconv.ParseInt(r.URL.Query().Get("after"), 10, 64)
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
	if limit <= 0 || limit > 200 {
		limit = 50
	}
	rows, err := store.ListInbound(r.Context(), a.Collector.DB, id, after, limit)
	if err != nil {
		a.internal(w, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"data": rows})
}

func (a *API) decision(w http.ResponseWriter, r *http.Request) {
	id, ok := tenant(w, r)
	if !ok {
		return
	}
	pdpID, err := strconv.ParseInt(r.PathValue("pdp"), 10, 64)
	if err != nil {
		writeErr(w, http.StatusBadRequest, "bad_id", "identifiant de facture invalide")
		return
	}
	var body reception.DecisionArgs
	if !readJSON(w, r, &body) {
		return
	}
	body.PDPInvoiceID = pdpID
	if err := a.Collector.Decide(r.Context(), id, body); err != nil {
		writeErr(w, http.StatusUnprocessableEntity, "decision", err.Error())
		return
	}
	w.WriteHeader(http.StatusAccepted)
}

// ---- Utilitaires --------------------------------------------------------------------

func tenant(w http.ResponseWriter, r *http.Request) (int64, bool) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil || id <= 0 {
		writeErr(w, http.StatusBadRequest, "bad_tenant", "identifiant de tenant invalide")
		return 0, false
	}
	return id, true
}

func readJSON(w http.ResponseWriter, r *http.Request, v any) bool {
	dec := json.NewDecoder(http.MaxBytesReader(w, r.Body, 5<<20))
	dec.DisallowUnknownFields()
	if err := dec.Decode(v); err != nil {
		writeErr(w, http.StatusBadRequest, "bad_json", err.Error())
		return false
	}
	return true
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, status int, code, msg string) {
	writeJSON(w, status, map[string]string{"error": code, "message": msg})
}

func (a *API) internal(w http.ResponseWriter, err error) {
	a.Log.Error("http", "event", "http.internal", "error", err.Error())
	writeErr(w, http.StatusInternalServerError, "internal", "erreur interne")
}

func parseDate(s *string) (*time.Time, error) {
	if s == nil || *s == "" {
		return nil, nil
	}
	t, err := time.Parse("2006-01-02", *s)
	if err != nil {
		return nil, fmt.Errorf("date %q : format AAAA-MM-JJ attendu", *s)
	}
	return &t, nil
}
