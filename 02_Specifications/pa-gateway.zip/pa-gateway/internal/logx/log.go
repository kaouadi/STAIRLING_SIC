// Package logx fournit un logger slog qui n'émet que des clés autorisées.
// Toute clé hors liste blanche sort en [FILTERED] : un jeton ajouté par
// erreur dans un log ne fuit jamais.
package logx

import (
	"io"
	"log/slog"
)

var allowed = map[string]bool{
	"time": true, "level": true, "msg": true,
	"flow": true, "event": true, "outcome": true, "trace_id": true,
	"tenant_id": true, "external_id": true, "outbound_id": true, "job_id": true, "job_kind": true,
	"pdp_invoice_id": true, "pdp_event_id": true, "http": true, "dur_ms": true,
	"status_code": true, "raw_code": true, "nature": true, "attempt": true,
	"rules": true, "state": true, "kyb_status": true, "count": true, "cursor": true,
	"error": true, "reason": true,
}

func New(w io.Writer) *slog.Logger {
	h := slog.NewTextHandler(w, &slog.HandlerOptions{
		ReplaceAttr: func(groups []string, a slog.Attr) slog.Attr {
			if len(groups) == 0 && !allowed[a.Key] {
				return slog.String(a.Key, "[FILTERED]")
			}
			return a
		},
	})
	return slog.New(h)
}
