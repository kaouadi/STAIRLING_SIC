package logx

import (
	"bytes"
	"strings"
	"testing"
)

func TestUnknownKeysAreFiltered(t *testing.T) {
	var buf bytes.Buffer
	New(&buf).Info("x", "tenant_id", 42, "access_token", "secret-at", "Authorization", "Bearer secret")
	out := buf.String()
	if strings.Contains(out, "secret") || !strings.Contains(out, "tenant_id=42") || !strings.Contains(out, "access_token=[FILTERED]") {
		t.Fatalf("log non expurgé : %s", out)
	}
}
