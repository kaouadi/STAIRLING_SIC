// Package oauth construit l'URL d'autorisation OAuth 2.1 + PKCE de SuperPDP.
package oauth

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"net/url"
	"strings"
)

// RandomToken renvoie n octets aléatoires encodés en base64url sans padding.
func RandomToken(n int) string {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		panic(err) // crypto/rand ne doit jamais échouer
	}
	return base64.RawURLEncoding.EncodeToString(b)
}

// NewVerifier : 32 octets → 43 caractères, dans la plage RFC 7636 (43 à 128).
func NewVerifier() string { return RandomToken(32) }

// Challenge = base64url(SHA-256(verifier)), sans padding (méthode S256).
func Challenge(verifier string) string {
	sum := sha256.Sum256([]byte(verifier))
	return base64.RawURLEncoding.EncodeToString(sum[:])
}

type AuthorizeParams struct {
	BaseURL      string // https://api.superpdp.tech
	ClientID     string
	RedirectURI  string
	State        string
	Verifier     string
	LoginHint    string // email du gérant (pré-remplissage)
	SIREN        string // 9 chiffres, jamais un SIRET
	NumberScheme string // fr_siren | sandbox — obligatoire si SIREN fourni
}

// AuthorizeURL construit l'URL de redirection. Les paramètres vides sont omis ;
// superpdp_company_number et son scheme vont toujours ensemble.
func AuthorizeURL(p AuthorizeParams) string {
	q := url.Values{
		"response_type":         {"code"},
		"client_id":             {p.ClientID},
		"redirect_uri":          {p.RedirectURI},
		"state":                 {p.State},
		"code_challenge":        {Challenge(p.Verifier)},
		"code_challenge_method": {"S256"},
	}
	if p.LoginHint != "" {
		q.Set("login_hint", p.LoginHint)
	}
	if p.SIREN != "" && p.NumberScheme != "" {
		q.Set("superpdp_company_number", p.SIREN)
		q.Set("superpdp_company_number_scheme", p.NumberScheme)
	}
	return strings.TrimRight(p.BaseURL, "/") + "/oauth2/authorize?" + q.Encode()
}

// SIRENFromSIRET dérive le SIREN (9 premiers chiffres) d'un SIRET valide.
func SIRENFromSIRET(siret string) (string, bool) {
	s := strings.ReplaceAll(siret, " ", "")
	if len(s) != 14 {
		return "", false
	}
	for _, r := range s {
		if r < '0' || r > '9' {
			return "", false
		}
	}
	return s[:9], true
}
