package oauth

import (
	"net/url"
	"strings"
	"testing"
)

func TestChallengeRFC7636(t *testing.T) {
	// Vecteur de test de la RFC 7636, annexe B.
	got := Challenge("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk")
	if want := "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM"; got != want {
		t.Fatalf("challenge = %s, want %s", got, want)
	}
	if v := NewVerifier(); len(v) < 43 || len(v) > 128 {
		t.Fatalf("verifier de longueur %d hors RFC", len(v))
	}
}

func TestAuthorizeURL(t *testing.T) {
	u := AuthorizeURL(AuthorizeParams{BaseURL: "https://api.superpdp.tech/", ClientID: "cid",
		RedirectURI: "https://app/cb", State: "st", Verifier: "v", LoginHint: "a@b.fr",
		SIREN: "123456789", NumberScheme: "fr_siren"})
	parsed, _ := url.Parse(u)
	q := parsed.Query()
	if !strings.HasPrefix(u, "https://api.superpdp.tech/oauth2/authorize?") ||
		q.Get("code_challenge_method") != "S256" || q.Get("superpdp_company_number") != "123456789" ||
		q.Get("superpdp_company_number_scheme") != "fr_siren" || q.Get("login_hint") != "a@b.fr" {
		t.Fatalf("URL inattendue: %s", u)
	}
	// Scheme sans SIREN : les deux paramètres sont omis ensemble.
	u = AuthorizeURL(AuthorizeParams{BaseURL: "x", NumberScheme: "fr_siren", Verifier: "v"})
	if strings.Contains(u, "superpdp_company_number") {
		t.Fatal("scheme émis sans SIREN")
	}
}

func TestSIRENFromSIRET(t *testing.T) {
	if s, ok := SIRENFromSIRET("732 829 320 00074"); !ok || s != "732829320" {
		t.Fatalf("got %q %v", s, ok)
	}
	for _, bad := range []string{"", "732829320", "7328293200007X", "123456789012345"} {
		if _, ok := SIRENFromSIRET(bad); ok {
			t.Fatalf("%q accepté", bad)
		}
	}
}
