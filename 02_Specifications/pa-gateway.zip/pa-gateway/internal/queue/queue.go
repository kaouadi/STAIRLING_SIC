// Package queue est une file de jobs minimale adossée à PostgreSQL
// (SELECT … FOR UPDATE SKIP LOCKED). Elle offre ce dont la passerelle a
// besoin, sans dépendance externe :
//
//   - mise en file dans la même transaction que la donnée métier ;
//   - unicité des jobs actifs (unique_key) ;
//   - trois issues distinctes pour un handler : erreur comptée (Retry),
//     report sans consommer de tentative (Snooze), abandon (Cancel) ;
//   - récupération des jobs bloqués après un crash.
//
// Elle peut être remplacée par riverqueue/river sans toucher aux handlers :
// la sémantique (erreur / snooze / cancel) est la même.
package queue

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"time"

	"github.com/stairling/pa-gateway/internal/store"
)

type Job struct {
	ID       int64
	Kind     string
	TenantID int64
	Args     json.RawMessage
	Attempt  int // numéro de la tentative en cours (1 = première)
}

func (j *Job) Decode(v any) error { return json.Unmarshal(j.Args, v) }

type Handler func(ctx context.Context, job *Job) error

// Snooze reporte le job sans consommer de tentative (échec non déterministe,
// ou condition extérieure : KYB en attente, réseau…).
type SnoozeError struct {
	After  time.Duration
	Reason error
}

func (e *SnoozeError) Error() string { return fmt.Sprintf("snooze %s: %v", e.After, e.Reason) }
func (e *SnoozeError) Unwrap() error { return e.Reason }

func Snooze(after time.Duration, reason error) error {
	return &SnoozeError{After: after, Reason: reason}
}

// Cancel abandonne le job définitivement.
type CancelError struct{ Reason error }

func (e *CancelError) Error() string { return "cancel: " + e.Reason.Error() }
func (e *CancelError) Unwrap() error { return e.Reason }

func Cancel(reason error) error { return &CancelError{Reason: reason} }

type EnqueueOpts struct {
	UniqueKey   string        // un seul job actif par clé
	Delay       time.Duration // exécution différée
	MaxAttempts int           // défaut 25
}

// Enqueue insère un job. Avec UniqueKey, un doublon actif est ignoré sans erreur
// (inserted=false). À appeler dans la transaction de la donnée métier.
func Enqueue(ctx context.Context, q store.DBTX, kind string, tenantID int64, args any, o EnqueueOpts) (inserted bool, err error) {
	payload, err := json.Marshal(args)
	if err != nil {
		return false, err
	}
	if o.MaxAttempts == 0 {
		o.MaxAttempts = 25
	}
	var key any
	if o.UniqueKey != "" {
		key = o.UniqueKey
	}
	res, err := q.ExecContext(ctx, `
		INSERT INTO pa_jobs (kind, tenant_id, args, unique_key, run_at, max_attempts)
		VALUES ($1,$2,$3,$4, now() + make_interval(secs => $5), $6)
		ON CONFLICT (unique_key) WHERE unique_key IS NOT NULL AND state IN ('available','running') DO NOTHING`,
		kind, tenantID, payload, key, o.Delay.Seconds(), o.MaxAttempts)
	if err != nil {
		return false, err
	}
	n, _ := res.RowsAffected()
	return n == 1, nil
}

type Worker struct {
	DB           *sql.DB
	Log          *slog.Logger
	Handlers     map[string]Handler
	Concurrency  int
	PollInterval time.Duration
	JobTimeout   time.Duration
	Backoff      func(attempt int) time.Duration
}

func DefaultBackoff(attempt int) time.Duration {
	d := time.Duration(1<<min(attempt, 10)) * 15 * time.Second
	if d > time.Hour {
		d = time.Hour
	}
	return d
}

func (w *Worker) defaults() {
	if w.Concurrency <= 0 {
		w.Concurrency = 4
	}
	if w.PollInterval == 0 {
		w.PollInterval = time.Second
	}
	if w.JobTimeout == 0 {
		w.JobTimeout = 5 * time.Minute
	}
	if w.Backoff == nil {
		w.Backoff = DefaultBackoff
	}
}

// Run lance les goroutines de traitement et le récupérateur. Bloque jusqu'à ctx.Done().
func (w *Worker) Run(ctx context.Context) {
	w.defaults()
	done := make(chan struct{})
	for i := 0; i < w.Concurrency; i++ {
		go func() {
			defer func() { done <- struct{}{} }()
			for ctx.Err() == nil {
				worked, err := w.RunOne(ctx)
				if err != nil && ctx.Err() == nil {
					w.Log.Error("queue", "event", "queue.fetch.ko", "error", err.Error())
				}
				if !worked {
					sleep(ctx, w.PollInterval)
				}
			}
		}()
	}
	go func() {
		for ctx.Err() == nil {
			_ = w.RescueStuck(ctx, 2*w.JobTimeout)
			sleep(ctx, time.Minute)
		}
	}()
	for i := 0; i < w.Concurrency; i++ {
		<-done
	}
}

// RunOne réserve et exécute au plus un job. Exposé pour les tests.
func (w *Worker) RunOne(ctx context.Context) (bool, error) {
	w.defaults()
	job, err := w.claim(ctx)
	if err != nil || job == nil {
		return false, err
	}
	h, ok := w.Handlers[job.Kind]
	var runErr error
	if !ok {
		runErr = Cancel(fmt.Errorf("aucun handler pour %q", job.Kind))
	} else {
		jctx, cancel := context.WithTimeout(ctx, w.JobTimeout)
		runErr = safeRun(jctx, h, job)
		cancel()
	}
	return true, w.complete(ctx, job, runErr)
}

func safeRun(ctx context.Context, h Handler, job *Job) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("panic: %v", r)
		}
	}()
	return h(ctx, job)
}

func (w *Worker) claim(ctx context.Context) (*Job, error) {
	var j Job
	err := w.DB.QueryRowContext(ctx, `
		UPDATE pa_jobs SET state='running', locked_at=now(), attempts=attempts+1
		WHERE id = (
			SELECT id FROM pa_jobs WHERE state='available' AND run_at <= now()
			ORDER BY run_at, id FOR UPDATE SKIP LOCKED LIMIT 1)
		RETURNING id, kind, tenant_id, args, attempts`).Scan(&j.ID, &j.Kind, &j.TenantID, &j.Args, &j.Attempt)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return &j, nil
}

func (w *Worker) complete(ctx context.Context, j *Job, runErr error) error {
	log := w.Log.With("job_id", j.ID, "job_kind", j.Kind, "tenant_id", j.TenantID, "attempt", j.Attempt)
	var snooze *SnoozeError
	var cancel *CancelError
	switch {
	case runErr == nil:
		_, err := w.DB.ExecContext(ctx, `UPDATE pa_jobs SET state='done', locked_at=NULL, last_error=NULL WHERE id=$1`, j.ID)
		return err
	case errors.As(runErr, &snooze):
		log.Info("queue", "event", "job.snoozed", "reason", runErr.Error())
		// Le snooze rend la tentative consommée par claim().
		_, err := w.DB.ExecContext(ctx, `UPDATE pa_jobs SET state='available', locked_at=NULL, attempts=attempts-1,
			run_at=now() + make_interval(secs => $2), last_error=$3 WHERE id=$1`, j.ID, snooze.After.Seconds(), runErr.Error())
		return err
	case errors.As(runErr, &cancel):
		log.Warn("queue", "event", "job.cancelled", "error", runErr.Error())
		_, err := w.DB.ExecContext(ctx, `UPDATE pa_jobs SET state='discarded', locked_at=NULL, last_error=$2 WHERE id=$1`,
			j.ID, runErr.Error())
		return err
	default:
		log.Warn("queue", "event", "job.failed", "error", runErr.Error())
		_, err := w.DB.ExecContext(ctx, `UPDATE pa_jobs SET locked_at=NULL, last_error=$2,
			state = CASE WHEN attempts >= max_attempts THEN 'discarded' ELSE 'available' END,
			run_at = now() + make_interval(secs => $3) WHERE id=$1`, j.ID, runErr.Error(), w.Backoff(j.Attempt).Seconds())
		return err
	}
}

// RescueStuck remet en file les jobs « running » abandonnés (crash d'un worker).
func (w *Worker) RescueStuck(ctx context.Context, olderThan time.Duration) error {
	_, err := w.DB.ExecContext(ctx, `UPDATE pa_jobs SET state='available', locked_at=NULL
		WHERE state='running' AND locked_at < now() - make_interval(secs => $1)`, olderThan.Seconds())
	return err
}

func sleep(ctx context.Context, d time.Duration) {
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-ctx.Done():
	case <-t.C:
	}
}
