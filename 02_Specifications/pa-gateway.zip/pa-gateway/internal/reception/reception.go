// Package reception collecte les factures reçues par polling (pas de webhook
// dans le contrat d'API SuperPDP à ce jour) et envoie les décisions de
// l'acheteur (fr:205 approuvée, fr:210 refusée).
//
// Quatre passes à curseur, toutes idempotentes :
//
//	factures   GET /invoices?direction=in…   → pa_inbound (JSON brut)
//	événements GET /invoice_events…          → pa_events (dans les deux sens, jamais coupée)
//	détail     GET /invoices/{id}            → pa_inbound.detail
//	natif      GET /invoices/{id}/download   → coffre + SHA-256
//
// Le curseur n'avance qu'après persistance, dans la même transaction.
package reception

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"time"

	"github.com/stairling/pa-gateway/internal/queue"
	"github.com/stairling/pa-gateway/internal/store"
	"github.com/stairling/pa-gateway/internal/superpdp"
	"github.com/stairling/pa-gateway/internal/tokens"
	"github.com/stairling/pa-gateway/internal/vault"
)

const (
	pageInvoices = 100
	pageEvents   = 1000
	maxPages     = 50 // borne par passe : le reste au tick suivant
	batchDetail  = 50
)

type Collector struct {
	DB     *sql.DB
	Tokens *tokens.Source
	Vault  vault.Store
	Log    *slog.Logger
}

// PassInvoices ingère les nouvelles factures reçues.
func (c *Collector) PassInvoices(ctx context.Context, tenantID int64, api *superpdp.Scoped) (int, error) {
	total := 0
	for page := 0; page < maxPages; page++ {
		cursor, err := store.GetCursor(ctx, c.DB, tenantID, "invoices_in")
		if err != nil {
			return total, err
		}
		items, err := api.ListIncoming(ctx, cursor, pageInvoices)
		if err != nil {
			return total, err // curseur intact : reprise au tick suivant
		}
		if len(items) == 0 {
			break
		}
		err = store.WithTx(ctx, c.DB, func(tx *sql.Tx) error {
			maxID := cursor
			for _, inv := range items {
				raw, _ := json.Marshal(inv)
				if err := store.InsertInbound(ctx, tx, tenantID, inv.ID, raw); err != nil {
					return err
				}
				if inv.ID > maxID {
					maxID = inv.ID
				}
			}
			return store.AdvanceCursor(ctx, tx, tenantID, "invoices_in", maxID)
		})
		if err != nil {
			return total, err
		}
		total += len(items)
		if len(items) < pageInvoices {
			break
		}
	}
	return total, nil
}

// PassEvents ingère tous les événements (émis et reçus). Les statuts de nos
// factures émises y arrivent aussi : cette passe n'est jamais coupée.
// Renvoie les identifiants de factures émises dont un statut a pu changer.
func (c *Collector) PassEvents(ctx context.Context, tenantID int64, api *superpdp.Scoped) (int, error) {
	total := 0
	for page := 0; page < maxPages; page++ {
		cursor, err := store.GetCursor(ctx, c.DB, tenantID, "events")
		if err != nil {
			return total, err
		}
		evs, err := api.ListEvents(ctx, cursor, pageEvents)
		if err != nil {
			return total, err
		}
		if len(evs) == 0 {
			break
		}
		err = store.WithTx(ctx, c.DB, func(tx *sql.Tx) error {
			maxID := cursor
			for _, ev := range evs {
				raw, _ := json.Marshal(ev)
				inserted, err := store.InsertEvent(ctx, tx, tenantID, ev.ID, ev.InvoiceID, ev.StatusCode, raw)
				if err != nil {
					return err
				}
				if inserted {
					if err := applyToOutbound(ctx, tx, tenantID, ev, raw); err != nil {
						return err
					}
				}
				if ev.ID > maxID {
					maxID = ev.ID
				}
			}
			return store.AdvanceCursor(ctx, tx, tenantID, "events", maxID)
		})
		if err != nil {
			return total, err
		}
		total += len(evs)
		if len(evs) < pageEvents {
			break
		}
	}
	return total, nil
}

// applyToOutbound reporte un événement sur la facture émise correspondante,
// si c'en est une (sinon l'événement concerne une facture reçue).
func applyToOutbound(ctx context.Context, tx *sql.Tx, tenantID int64, ev superpdp.Event, raw []byte) error {
	out, err := store.GetOutboundByPDPID(ctx, tx, tenantID, ev.InvoiceID)
	if errors.Is(err, store.ErrNotFound) {
		return nil
	}
	if err != nil {
		return err
	}
	var codePtr *int
	if code, ok := superpdp.MapStatus(ev.StatusCode); ok {
		codePtr = &code
	}
	_, err = store.RecordStatus(ctx, tx, out.ID, codePtr, ev.StatusCode, ev.Reason(), raw)
	return err
}

// PassDetail complète les factures dont on n'a que la ligne de liste.
func (c *Collector) PassDetail(ctx context.Context, tenantID int64, api *superpdp.Scoped) (int, error) {
	ids, err := store.InboundMissingDetail(ctx, c.DB, tenantID, batchDetail)
	if err != nil {
		return 0, err
	}
	n := 0
	for _, id := range ids {
		inv, err := api.GetInvoice(ctx, id)
		if err != nil {
			return n, err
		}
		raw, _ := json.Marshal(inv)
		if err := store.SetInboundDetail(ctx, c.DB, tenantID, id, raw); err != nil {
			return n, err
		}
		n++
	}
	return n, nil
}

// PassNative dépose le fichier natif au coffre, avec son empreinte.
func (c *Collector) PassNative(ctx context.Context, tenantID int64, api *superpdp.Scoped) (int, error) {
	ids, err := store.InboundMissingNative(ctx, c.DB, tenantID, batchDetail)
	if err != nil {
		return 0, err
	}
	n := 0
	for _, id := range ids {
		data, err := api.Download(ctx, id)
		if err != nil {
			return n, err
		}
		sum := sha256.Sum256(data)
		sha := hex.EncodeToString(sum[:])
		key := fmt.Sprintf("tenant-%d/inbound/%d-%s", tenantID, id, sha[:12])
		if err := c.Vault.Put(ctx, key, data); err != nil {
			return n, err
		}
		if err := store.SetInboundNative(ctx, c.DB, tenantID, id, key, sha); err != nil {
			return n, err
		}
		n++
	}
	return n, nil
}

// ---- Décision de l'acheteur ----------------------------------------------------

type DecisionArgs struct {
	PDPInvoiceID int64  `json:"pdp_invoice_id"`
	Decision     string `json:"decision"`              // approved | refused
	ReasonCode   string `json:"reason_code,omitempty"` // motif normalisé, obligatoire pour un refus
	ReasonText   string `json:"reason_text,omitempty"`
}

var ErrReasonRequired = errors.New("un refus exige un motif normalisé")

// Decide enregistre la décision (irréversible) et met l'envoi en file.
func (c *Collector) Decide(ctx context.Context, tenantID int64, a DecisionArgs) error {
	if a.Decision != "approved" && a.Decision != "refused" {
		return errors.New("décision attendue : approved ou refused")
	}
	if a.Decision == "refused" && a.ReasonCode == "" {
		return ErrReasonRequired
	}
	return store.WithTx(ctx, c.DB, func(tx *sql.Tx) error {
		if err := store.SetDecision(ctx, tx, tenantID, a.PDPInvoiceID, a.Decision); err != nil {
			return err
		}
		_, err := queue.Enqueue(ctx, tx, "decision", tenantID, a,
			queue.EnqueueOpts{UniqueKey: fmt.Sprintf("decision:%d:%d", tenantID, a.PDPInvoiceID)})
		return err
	})
}

// HandleDecision envoie fr:205 ou fr:210. Rejoué jusqu'au succès : la fiche
// ne doit pas rester « en cours de transmission » après un échec.
func (c *Collector) HandleDecision(ctx context.Context, job *queue.Job) error {
	var a DecisionArgs
	if err := job.Decode(&a); err != nil {
		return queue.Cancel(err)
	}
	api, _, err := c.Tokens.Client(ctx, job.TenantID)
	if err != nil {
		return queue.Snooze(time.Hour, err)
	}
	code := "fr:205"
	details := map[string]any{}
	if a.Decision == "refused" {
		code = "fr:210"
		details["reason_code"] = a.ReasonCode
		if a.ReasonText != "" {
			details["reason"] = a.ReasonText
		}
	}
	_, err = api.CreateEvent(ctx, superpdp.NewEvent{InvoiceID: a.PDPInvoiceID, StatusCode: code, Details: details})
	var tr *superpdp.TransientError
	if errors.As(err, &tr) {
		return queue.Snooze(15*time.Minute, err)
	}
	if err != nil {
		return err
	}
	c.Log.Info("receive", "flow", "receive", "event", "decision.sent", "tenant_id", job.TenantID,
		"pdp_invoice_id", a.PDPInvoiceID, "raw_code", code)
	return store.MarkDecisionSent(ctx, c.DB, job.TenantID, a.PDPInvoiceID)
}
