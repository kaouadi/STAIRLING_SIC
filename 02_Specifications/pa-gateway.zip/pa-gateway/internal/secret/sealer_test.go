package secret

import (
	"bytes"
	"testing"
)

func TestSealRoundTripAndKeyChange(t *testing.T) {
	s, _ := NewSealer(bytes.Repeat([]byte{1}, 32))
	c1, _ := s.Seal("refresh-token")
	c2, _ := s.Seal("refresh-token")
	if bytes.Equal(c1, c2) {
		t.Fatal("nonce réutilisé")
	}
	if got, err := s.Open(c1); err != nil || got != "refresh-token" {
		t.Fatalf("aller-retour KO: %q %v", got, err)
	}
	other, _ := NewSealer(bytes.Repeat([]byte{2}, 32))
	if _, err := other.Open(c1); err == nil {
		t.Fatal("déchiffré avec une autre clé")
	}
}
