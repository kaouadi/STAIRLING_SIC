// Package store regroupe l'accès PostgreSQL de la passerelle.
// Toutes les fonctions acceptent un DBTX : *sql.DB ou *sql.Tx, pour que
// l'appelant décide de ce qui est atomique.
package store

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"time"
)

type DBTX interface {
	ExecContext(ctx context.Context, query string, args ...any) (sql.Result, error)
	QueryContext(ctx context.Context, query string, args ...any) (*sql.Rows, error)
	QueryRowContext(ctx context.Context, query string, args ...any) *sql.Row
}

var (
	ErrNotFound           = errors.New("store: introuvable")
	ErrAlreadyTransmitted = errors.New("store: facture déjà transmise, elle ne repart jamais")
	ErrStateInvalid       = errors.New("store: state OAuth inconnu, expiré ou déjà consommé")
)

// WithTx exécute fn dans une transaction (commit si nil, rollback sinon).
func WithTx(ctx context.Context, db *sql.DB, fn func(tx *sql.Tx) error) error {
	tx, err := db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	if err := fn(tx); err != nil {
		_ = tx.Rollback()
		return err
	}
	return tx.Commit()
}

// ============================================================================
// Raccordement
// ============================================================================

type Connection struct {
	TenantID             int64
	SIREN                string
	LoginEmail           string
	State                string
	KYBStatus            sql.NullString
	CompanyID            sql.NullInt64
	AccessTokenEnc       []byte
	RefreshTokenEnc      []byte
	ExpiresAt            sql.NullTime
	EmissionEnabledFrom  sql.NullTime
	ReceptionEnabledFrom sql.NullTime
}

const connCols = `tenant_id, siren, login_email, state, kyb_status, company_id,
	access_token_enc, refresh_token_enc, expires_at, emission_enabled_from, reception_enabled_from`

func scanConn(row interface{ Scan(...any) error }) (*Connection, error) {
	var c Connection
	err := row.Scan(&c.TenantID, &c.SIREN, &c.LoginEmail, &c.State, &c.KYBStatus, &c.CompanyID,
		&c.AccessTokenEnc, &c.RefreshTokenEnc, &c.ExpiresAt, &c.EmissionEnabledFrom, &c.ReceptionEnabledFrom)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	return &c, err
}

func GetConnection(ctx context.Context, q DBTX, tenantID int64) (*Connection, error) {
	return scanConn(q.QueryRowContext(ctx, `SELECT `+connCols+` FROM pa_connections WHERE tenant_id=$1`, tenantID))
}

// GetConnectionForUpdate : à utiliser dans une transaction qui tient le verrou du tenant.
func GetConnectionForUpdate(ctx context.Context, tx *sql.Tx, tenantID int64) (*Connection, error) {
	return scanConn(tx.QueryRowContext(ctx, `SELECT `+connCols+` FROM pa_connections WHERE tenant_id=$1 FOR UPDATE`, tenantID))
}

func UpsertIdentity(ctx context.Context, q DBTX, tenantID int64, siren, email string) error {
	_, err := q.ExecContext(ctx, `
		INSERT INTO pa_connections (tenant_id, siren, login_email) VALUES ($1,$2,$3)
		ON CONFLICT (tenant_id) DO UPDATE SET siren=EXCLUDED.siren, login_email=EXCLUDED.login_email, updated_at=now()`,
		tenantID, siren, email)
	return err
}

func SaveTokens(ctx context.Context, q DBTX, tenantID int64, accessEnc, refreshEnc []byte, expiresAt time.Time) error {
	_, err := q.ExecContext(ctx, `
		UPDATE pa_connections SET access_token_enc=$2, refresh_token_enc=$3, expires_at=$4, updated_at=now()
		WHERE tenant_id=$1`, tenantID, accessEnc, refreshEnc, expiresAt)
	return err
}

func SetState(ctx context.Context, q DBTX, tenantID int64, state string, kyb *string) error {
	_, err := q.ExecContext(ctx, `
		UPDATE pa_connections SET state=$2, kyb_status=COALESCE($3, kyb_status), updated_at=now()
		WHERE tenant_id=$1`, tenantID, state, kyb)
	return err
}

func SetCompanyID(ctx context.Context, q DBTX, tenantID, companyID int64) error {
	_, err := q.ExecContext(ctx, `UPDATE pa_connections SET company_id=$2 WHERE tenant_id=$1`, tenantID, companyID)
	return err
}

// Disconnect efface les jetons ; la connexion repart de zéro.
func Disconnect(ctx context.Context, q DBTX, tenantID int64) error {
	_, err := q.ExecContext(ctx, `
		UPDATE pa_connections SET state='disconnected', access_token_enc=NULL, refresh_token_enc=NULL,
			expires_at=NULL, updated_at=now() WHERE tenant_id=$1`, tenantID)
	return err
}

// SetEnablement pose (ou coupe, avec nil) les dates d'ouverture émission / réception.
func SetEnablement(ctx context.Context, q DBTX, tenantID int64, emission, reception *time.Time) error {
	_, err := q.ExecContext(ctx, `
		UPDATE pa_connections SET emission_enabled_from=$2, reception_enabled_from=$3, updated_at=now()
		WHERE tenant_id=$1`, tenantID, emission, reception)
	return err
}

func ConnectedTenants(ctx context.Context, q DBTX) ([]int64, error) {
	rows, err := q.QueryContext(ctx, `SELECT tenant_id FROM pa_connections WHERE state='connected' ORDER BY tenant_id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var ids []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	return ids, rows.Err()
}

// LockTenantTokens prend un verrou consultatif transactionnel, propre au tenant.
// Il sérialise le rafraîchissement : le refresh token tourne à chaque appel,
// deux rafraîchissements concurrents casseraient la connexion.
func LockTenantTokens(ctx context.Context, tx *sql.Tx, tenantID int64) error {
	_, err := tx.ExecContext(ctx, `SELECT pg_advisory_xact_lock(hashtextextended('pa:tokens:' || $1::text, 0))`, tenantID)
	return err
}

// ---- Demandes OAuth -------------------------------------------------------------

func SaveOAuthRequest(ctx context.Context, q DBTX, state string, tenantID int64, verifierEnc []byte) error {
	_, err := q.ExecContext(ctx, `INSERT INTO pa_oauth_requests (state, tenant_id, verifier_enc) VALUES ($1,$2,$3)`,
		state, tenantID, verifierEnc)
	return err
}

// ConsumeOAuthRequest marque le state consommé (usage unique, validité 15 min).
func ConsumeOAuthRequest(ctx context.Context, q DBTX, state string) (tenantID int64, verifierEnc []byte, err error) {
	err = q.QueryRowContext(ctx, `
		UPDATE pa_oauth_requests SET consumed_at=now()
		WHERE state=$1 AND consumed_at IS NULL AND created_at > now() - interval '15 minutes'
		RETURNING tenant_id, verifier_enc`, state).Scan(&tenantID, &verifierEnc)
	if errors.Is(err, sql.ErrNoRows) {
		return 0, nil, ErrStateInvalid
	}
	return tenantID, verifierEnc, err
}

// ============================================================================
// Émission
// ============================================================================

type Outbound struct {
	ID           int64
	TenantID     int64
	ExternalID   string
	Payload      json.RawMessage
	IssueDate    time.Time
	PDPInvoiceID sql.NullInt64
	StatusCode   sql.NullInt64
	Nature       sql.NullString
	Attempts     int
	LastError    sql.NullString
}

const outCols = `id, tenant_id, external_id, payload, issue_date, pdp_invoice_id, status_code, nature, attempts, last_error`

func scanOut(row interface{ Scan(...any) error }) (*Outbound, error) {
	var o Outbound
	err := row.Scan(&o.ID, &o.TenantID, &o.ExternalID, &o.Payload, &o.IssueDate, &o.PDPInvoiceID,
		&o.StatusCode, &o.Nature, &o.Attempts, &o.LastError)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	return &o, err
}

// SubmitOutbound enregistre (ou remplace) une facture à émettre. Une resoumission
// d'une facture non transmise remet le compteur à zéro : c'est la seule sortie
// de l'état « exhausted ». Une facture déjà transmise est refusée.
func SubmitOutbound(ctx context.Context, q DBTX, tenantID int64, externalID string, payload []byte, issueDate time.Time) (int64, error) {
	var id int64
	var transmitted bool
	err := q.QueryRowContext(ctx, `
		INSERT INTO pa_outbound (tenant_id, external_id, payload, issue_date)
		VALUES ($1,$2,$3,$4)
		ON CONFLICT (tenant_id, external_id) DO UPDATE
			SET payload = CASE WHEN pa_outbound.pdp_invoice_id IS NULL THEN EXCLUDED.payload ELSE pa_outbound.payload END,
			    issue_date = CASE WHEN pa_outbound.pdp_invoice_id IS NULL THEN EXCLUDED.issue_date ELSE pa_outbound.issue_date END,
			    attempts = CASE WHEN pa_outbound.pdp_invoice_id IS NULL THEN 0 ELSE pa_outbound.attempts END,
			    nature = CASE WHEN pa_outbound.pdp_invoice_id IS NULL THEN NULL ELSE pa_outbound.nature END,
			    updated_at = now()
		RETURNING id, pdp_invoice_id IS NOT NULL`,
		tenantID, externalID, payload, issueDate).Scan(&id, &transmitted)
	if err != nil {
		return 0, err
	}
	if transmitted {
		return id, ErrAlreadyTransmitted
	}
	return id, nil
}

func GetOutbound(ctx context.Context, q DBTX, id int64) (*Outbound, error) {
	return scanOut(q.QueryRowContext(ctx, `SELECT `+outCols+` FROM pa_outbound WHERE id=$1`, id))
}

func GetOutboundByExternal(ctx context.Context, q DBTX, tenantID int64, externalID string) (*Outbound, error) {
	return scanOut(q.QueryRowContext(ctx, `SELECT `+outCols+` FROM pa_outbound WHERE tenant_id=$1 AND external_id=$2`,
		tenantID, externalID))
}

func GetOutboundByPDPID(ctx context.Context, q DBTX, tenantID, pdpID int64) (*Outbound, error) {
	return scanOut(q.QueryRowContext(ctx, `SELECT `+outCols+` FROM pa_outbound WHERE tenant_id=$1 AND pdp_invoice_id=$2`,
		tenantID, pdpID))
}

// MarkTransmitted : la facture a un identifiant plateforme, elle ne repartira jamais.
func MarkTransmitted(ctx context.Context, q DBTX, id, pdpID int64) error {
	_, err := q.ExecContext(ctx, `
		UPDATE pa_outbound SET pdp_invoice_id=$2, nature=NULL, last_error=NULL, updated_at=now()
		WHERE id=$1 AND pdp_invoice_id IS NULL`, id, pdpID)
	return err
}

// MarkFailure enregistre la nature de l'échec. countAttempt=true pour les
// échecs déterministes (invalid, refused) ; renvoie le compteur à jour.
func MarkFailure(ctx context.Context, q DBTX, id int64, nature, msg string, countAttempt bool) (int, error) {
	inc := 0
	if countAttempt {
		inc = 1
	}
	var attempts int
	err := q.QueryRowContext(ctx, `
		UPDATE pa_outbound SET nature=$2, last_error=$3, attempts=attempts+$4, updated_at=now()
		WHERE id=$1 RETURNING attempts`, id, nature, msg, inc).Scan(&attempts)
	return attempts, err
}

// RecordStatus ajoute une ligne d'historique et, si le code est connu et
// différent, met à jour le statut courant. Renvoie true si le statut a changé.
func RecordStatus(ctx context.Context, q DBTX, outboundID int64, code *int, rawCode, reason string, raw []byte) (bool, error) {
	var current sql.NullInt64
	if err := q.QueryRowContext(ctx, `SELECT status_code FROM pa_outbound WHERE id=$1`, outboundID).Scan(&current); err != nil {
		return false, err
	}
	if code != nil && current.Valid && int(current.Int64) == *code {
		return false, nil
	}
	if raw == nil {
		raw = []byte("null")
	}
	if _, err := q.ExecContext(ctx, `
		INSERT INTO pa_status_history (outbound_id, status_code, raw_code, reason, raw) VALUES ($1,$2,$3,NULLIF($4,''),$5)`,
		outboundID, code, rawCode, reason, raw); err != nil {
		return false, err
	}
	if code == nil { // code inconnu : conservé brut, n'écrase pas le statut courant
		return false, nil
	}
	_, err := q.ExecContext(ctx, `UPDATE pa_outbound SET status_code=$2, updated_at=now() WHERE id=$1`, outboundID, *code)
	return err == nil, err
}

// InFlight : transmises et pas encore à un statut final.
func InFlight(ctx context.Context, q DBTX, tenantID int64) ([]Outbound, error) {
	rows, err := q.QueryContext(ctx, `SELECT `+outCols+` FROM pa_outbound
		WHERE tenant_id=$1 AND pdp_invoice_id IS NOT NULL
		  AND (status_code IS NULL OR status_code NOT IN (210,212,213))
		ORDER BY id`, tenantID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Outbound
	for rows.Next() {
		o, err := scanOut(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, *o)
	}
	return out, rows.Err()
}

type StatusLine struct {
	StatusCode sql.NullInt64 `json:"-"`
	Code       *int64        `json:"status_code"`
	RawCode    string        `json:"raw_code"`
	Reason     string        `json:"reason,omitempty"`
	At         time.Time     `json:"at"`
}

func History(ctx context.Context, q DBTX, outboundID int64) ([]StatusLine, error) {
	rows, err := q.QueryContext(ctx, `SELECT status_code, raw_code, COALESCE(reason,''), at
		FROM pa_status_history WHERE outbound_id=$1 ORDER BY id`, outboundID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []StatusLine
	for rows.Next() {
		var l StatusLine
		if err := rows.Scan(&l.StatusCode, &l.RawCode, &l.Reason, &l.At); err != nil {
			return nil, err
		}
		if l.StatusCode.Valid {
			v := l.StatusCode.Int64
			l.Code = &v
		}
		out = append(out, l)
	}
	return out, rows.Err()
}

// ============================================================================
// Réception
// ============================================================================

func GetCursor(ctx context.Context, q DBTX, tenantID int64, name string) (int64, error) {
	var v int64
	err := q.QueryRowContext(ctx, `SELECT value FROM pa_cursors WHERE tenant_id=$1 AND name=$2`, tenantID, name).Scan(&v)
	if errors.Is(err, sql.ErrNoRows) {
		return 0, nil
	}
	return v, err
}

// AdvanceCursor ne recule jamais (GREATEST), même si deux passes se chevauchent.
func AdvanceCursor(ctx context.Context, q DBTX, tenantID int64, name string, value int64) error {
	_, err := q.ExecContext(ctx, `
		INSERT INTO pa_cursors (tenant_id, name, value) VALUES ($1,$2,$3)
		ON CONFLICT (tenant_id, name) DO UPDATE SET value = GREATEST(pa_cursors.value, EXCLUDED.value)`,
		tenantID, name, value)
	return err
}

// InsertInbound est idempotent : un re-fetch après crash est absorbé sans doublon.
func InsertInbound(ctx context.Context, q DBTX, tenantID, pdpID int64, raw []byte) error {
	_, err := q.ExecContext(ctx, `INSERT INTO pa_inbound (tenant_id, pdp_invoice_id, raw) VALUES ($1,$2,$3)
		ON CONFLICT DO NOTHING`, tenantID, pdpID, raw)
	return err
}

func InsertEvent(ctx context.Context, q DBTX, tenantID, eventID, invoiceID int64, rawCode string, raw []byte) (bool, error) {
	res, err := q.ExecContext(ctx, `INSERT INTO pa_events (tenant_id, pdp_event_id, pdp_invoice_id, raw_code, raw)
		VALUES ($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING`, tenantID, eventID, invoiceID, rawCode, raw)
	if err != nil {
		return false, err
	}
	n, _ := res.RowsAffected()
	return n == 1, nil
}

func inboundIDs(ctx context.Context, q DBTX, query string, tenantID int64, limit int) ([]int64, error) {
	rows, err := q.QueryContext(ctx, query, tenantID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var ids []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	return ids, rows.Err()
}

func InboundMissingDetail(ctx context.Context, q DBTX, tenantID int64, limit int) ([]int64, error) {
	return inboundIDs(ctx, q, `SELECT pdp_invoice_id FROM pa_inbound WHERE tenant_id=$1 AND detail IS NULL
		ORDER BY pdp_invoice_id LIMIT $2`, tenantID, limit)
}

func InboundMissingNative(ctx context.Context, q DBTX, tenantID int64, limit int) ([]int64, error) {
	return inboundIDs(ctx, q, `SELECT pdp_invoice_id FROM pa_inbound WHERE tenant_id=$1 AND native_key IS NULL
		ORDER BY pdp_invoice_id LIMIT $2`, tenantID, limit)
}

func SetInboundDetail(ctx context.Context, q DBTX, tenantID, pdpID int64, detail []byte) error {
	_, err := q.ExecContext(ctx, `UPDATE pa_inbound SET detail=$3 WHERE tenant_id=$1 AND pdp_invoice_id=$2`,
		tenantID, pdpID, detail)
	return err
}

func SetInboundNative(ctx context.Context, q DBTX, tenantID, pdpID int64, key, sha string) error {
	_, err := q.ExecContext(ctx, `UPDATE pa_inbound SET native_key=$3, native_sha256=$4
		WHERE tenant_id=$1 AND pdp_invoice_id=$2`, tenantID, pdpID, key, sha)
	return err
}

// SetDecision enregistre la décision (irréversible) ; l'envoi se fait par job.
func SetDecision(ctx context.Context, q DBTX, tenantID, pdpID int64, decision string) error {
	res, err := q.ExecContext(ctx, `UPDATE pa_inbound SET decision=$3, decision_sent=false
		WHERE tenant_id=$1 AND pdp_invoice_id=$2 AND decision IS NULL`, tenantID, pdpID, decision)
	if err != nil {
		return err
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return errors.New("store: facture reçue introuvable ou décision déjà prise")
	}
	return nil
}

func MarkDecisionSent(ctx context.Context, q DBTX, tenantID, pdpID int64) error {
	_, err := q.ExecContext(ctx, `UPDATE pa_inbound SET decision_sent=true WHERE tenant_id=$1 AND pdp_invoice_id=$2`,
		tenantID, pdpID)
	return err
}

type InboundRow struct {
	PDPInvoiceID int64           `json:"pdp_invoice_id"`
	Raw          json.RawMessage `json:"raw"`
	HasNative    bool            `json:"has_native"`
	Decision     *string         `json:"decision"`
	DecisionSent bool            `json:"decision_sent"`
}

func ListInbound(ctx context.Context, q DBTX, tenantID, after int64, limit int) ([]InboundRow, error) {
	rows, err := q.QueryContext(ctx, `SELECT pdp_invoice_id, COALESCE(detail, raw), native_key IS NOT NULL, decision, decision_sent
		FROM pa_inbound WHERE tenant_id=$1 AND pdp_invoice_id > $2 ORDER BY pdp_invoice_id LIMIT $3`,
		tenantID, after, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []InboundRow
	for rows.Next() {
		var r InboundRow
		var d sql.NullString
		if err := rows.Scan(&r.PDPInvoiceID, &r.Raw, &r.HasNative, &d, &r.DecisionSent); err != nil {
			return nil, err
		}
		if d.Valid {
			r.Decision = &d.String
		}
		out = append(out, r)
	}
	return out, rows.Err()
}
