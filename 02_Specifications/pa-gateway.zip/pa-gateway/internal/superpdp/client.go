// Package superpdp est le client HTTP de la plateforme agréée SuperPDP.
//
// Il ne connaît ni les tenants ni la base : il reçoit un access token par
// appel (via Scoped) et transforme chaque réponse en valeur ou en erreur typée
// (voir errors.go). Toute la politique de reprise est décidée plus haut.
package superpdp

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"
)

type Client struct {
	BaseURL      string // https://api.superpdp.tech
	ClientID     string
	ClientSecret string
	HTTP         *http.Client
	limiter      *limiter
}

func New(baseURL, clientID, clientSecret string, perSecond int) *Client {
	return &Client{
		BaseURL:      strings.TrimRight(baseURL, "/"),
		ClientID:     clientID,
		ClientSecret: clientSecret,
		HTTP:         &http.Client{Timeout: 60 * time.Second},
		limiter:      newLimiter(perSecond),
	}
}

func (c *Client) api(path string) string { return c.BaseURL + "/v1.beta" + path }

// ---- OAuth ----------------------------------------------------------------

// ExchangeCode échange le code d'autorisation contre les jetons (PKCE).
func (c *Client) ExchangeCode(ctx context.Context, code, verifier, redirectURI string) (*Token, error) {
	return c.token(ctx, url.Values{
		"grant_type":    {"authorization_code"},
		"code":          {code},
		"redirect_uri":  {redirectURI},
		"code_verifier": {verifier},
	})
}

// Refresh consomme le refresh token et en renvoie un NOUVEAU (rotation) :
// l'ancien devient invalide dès cet appel.
func (c *Client) Refresh(ctx context.Context, refreshToken string) (*Token, error) {
	return c.token(ctx, url.Values{
		"grant_type":    {"refresh_token"},
		"refresh_token": {refreshToken},
	})
}

func (c *Client) token(ctx context.Context, form url.Values) (*Token, error) {
	form.Set("client_id", c.ClientID)
	form.Set("client_secret", c.ClientSecret)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.BaseURL+"/oauth2/token",
		strings.NewReader(form.Encode()))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	body, status, err := c.send(ctx, req)
	if err != nil {
		return nil, err
	}
	if status >= 400 {
		var oe struct {
			Error string `json:"error"`
		}
		_ = json.Unmarshal(body, &oe)
		if oe.Error == "invalid_grant" {
			return nil, ErrInvalidGrant
		}
		return nil, classifyHTTP(status, string(body))
	}
	var t Token
	if err := json.Unmarshal(body, &t); err != nil {
		return nil, fmt.Errorf("superpdp: réponse token illisible: %w", err)
	}
	if t.ExpiresIn <= 0 {
		t.ExpiresIn = 1800 // valeur non garantie par la plateforme : défaut 30 min
	}
	return &t, nil
}

// ---- Appels authentifiés ------------------------------------------------------

// Scoped lie le client à l'access token d'un tenant.
type Scoped struct {
	c     *Client
	token string
}

func (c *Client) As(accessToken string) *Scoped { return &Scoped{c: c, token: accessToken} }

func (s *Scoped) SessionMe(ctx context.Context) (*Session, error) {
	var out Session
	return &out, s.getJSON(ctx, "/oauth2_sessions/me", nil, &out)
}

func (s *Scoped) CompanyMe(ctx context.Context) (*Company, error) {
	var out Company
	return &out, s.getJSON(ctx, "/companies/me", nil, &out)
}

// Convert transforme un JSON EN 16931 en Factur-X (PDF) côté plateforme.
func (s *Scoped) Convert(ctx context.Context, enInvoice json.RawMessage) ([]byte, error) {
	q := url.Values{"from": {"en16931"}, "to": {"factur-x"}}
	return s.do(ctx, http.MethodPost, "/invoices/convert", q, "application/json", enInvoice)
}

// Upload dépose le fichier (Factur-X, UBL ou CII) et renvoie la facture créée.
func (s *Scoped) Upload(ctx context.Context, file []byte, contentType, externalID string) (*Invoice, error) {
	q := url.Values{"external_id": {externalID}, "expand[]": {"events"}}
	body, err := s.do(ctx, http.MethodPost, "/invoices", q, contentType, file)
	if err != nil {
		return nil, err
	}
	var inv Invoice
	return &inv, decode(body, &inv)
}

func (s *Scoped) GetInvoice(ctx context.Context, id int64) (*Invoice, error) {
	var out Invoice
	q := url.Values{"expand[]": {"en_invoice", "events"}}
	return &out, s.getJSON(ctx, "/invoices/"+strconv.FormatInt(id, 10), q, &out)
}

// ListIncoming lit les factures reçues après le curseur, dans l'ordre croissant.
// Sans expand[], la liste ne contient ni montants ni événements.
func (s *Scoped) ListIncoming(ctx context.Context, after int64, limit int) ([]Invoice, error) {
	q := url.Values{
		"direction": {"in"}, "order": {"asc"},
		"starting_after_id": {strconv.FormatInt(after, 10)},
		"limit":             {strconv.Itoa(limit)},
		"expand[]":          {"en_invoice", "events"},
	}
	var p Page[Invoice]
	return p.Data, s.getJSON(ctx, "/invoices", q, &p)
}

// ListEvents lit les événements (dans les deux sens) après le curseur.
func (s *Scoped) ListEvents(ctx context.Context, after int64, limit int) ([]Event, error) {
	q := url.Values{
		"starting_after_id": {strconv.FormatInt(after, 10)},
		"limit":             {strconv.Itoa(limit)},
	}
	var p Page[Event]
	return p.Data, s.getJSON(ctx, "/invoice_events", q, &p)
}

// Download renvoie le fichier natif (Factur-X ou XML) tel que déposé.
func (s *Scoped) Download(ctx context.Context, id int64) ([]byte, error) {
	return s.do(ctx, http.MethodGet, "/invoices/"+strconv.FormatInt(id, 10)+"/download", nil, "", nil)
}

// NewEvent : statut émis par nous (fr:205, fr:210, fr:212…).
type NewEvent struct {
	InvoiceID  int64          `json:"invoice_id"`
	StatusCode string         `json:"status_code"`
	Details    map[string]any `json:"details,omitempty"` // motif, montant encaissé… ⚠ forme à vérifier dans la spec
}

func (s *Scoped) CreateEvent(ctx context.Context, e NewEvent) (*Event, error) {
	payload, _ := json.Marshal(e)
	body, err := s.do(ctx, http.MethodPost, "/invoice_events", nil, "application/json", payload)
	if err != nil {
		return nil, err
	}
	var out Event
	return &out, decode(body, &out)
}

// ---- Plomberie ------------------------------------------------------------------

func (s *Scoped) getJSON(ctx context.Context, path string, q url.Values, out any) error {
	body, err := s.do(ctx, http.MethodGet, path, q, "", nil)
	if err != nil {
		return err
	}
	return decode(body, out)
}

func (s *Scoped) do(ctx context.Context, method, path string, q url.Values, ctype string, payload []byte) ([]byte, error) {
	u := s.c.api(path)
	if len(q) > 0 {
		u += "?" + q.Encode()
	}
	var rd io.Reader
	if payload != nil {
		rd = bytes.NewReader(payload)
	}
	req, err := http.NewRequestWithContext(ctx, method, u, rd)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+s.token)
	if ctype != "" {
		req.Header.Set("Content-Type", ctype)
	}
	body, status, err := s.c.send(ctx, req)
	if err != nil {
		return nil, err
	}
	if status >= 400 {
		return nil, classifyHTTP(status, string(body))
	}
	return body, nil
}

// send applique le limiteur et convertit les erreurs réseau en TransientError.
// Aucun retry ici : un POST rejoué à l'aveugle peut créer un doublon fiscal.
func (c *Client) send(ctx context.Context, req *http.Request) ([]byte, int, error) {
	if err := c.limiter.wait(ctx); err != nil {
		return nil, 0, err
	}
	resp, err := c.HTTP.Do(req)
	if err != nil {
		if errors.Is(err, context.Canceled) {
			return nil, 0, err
		}
		return nil, 0, &TransientError{Err: err}
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, 50<<20))
	if err != nil {
		return nil, 0, &TransientError{Err: err}
	}
	return body, resp.StatusCode, nil
}

func decode(body []byte, out any) error {
	if err := json.Unmarshal(body, out); err != nil {
		return fmt.Errorf("superpdp: réponse JSON illisible: %w", err)
	}
	return nil
}

// limiter : intervalle minimal entre deux appels, partagé par tous les workers.
type limiter struct {
	mu       sync.Mutex
	interval time.Duration
	next     time.Time
}

func newLimiter(perSecond int) *limiter {
	if perSecond <= 0 {
		perSecond = 20
	}
	return &limiter{interval: time.Second / time.Duration(perSecond)}
}

func (l *limiter) wait(ctx context.Context) error {
	l.mu.Lock()
	now := time.Now()
	if l.next.Before(now) {
		l.next = now
	}
	at := l.next
	l.next = l.next.Add(l.interval)
	l.mu.Unlock()
	d := time.Until(at)
	if d <= 0 {
		return nil
	}
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-t.C:
		return nil
	}
}
