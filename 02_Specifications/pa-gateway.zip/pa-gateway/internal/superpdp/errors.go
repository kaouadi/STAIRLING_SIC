package superpdp

import (
	"errors"
	"fmt"
	"regexp"
	"sort"
)

// Erreurs sentinelles, testables avec errors.Is.
var (
	ErrUnauthorized = errors.New("superpdp: 401 jeton refusé")
	ErrForbidden    = errors.New("superpdp: 403 accès refusé (KYB non vérifié ?)")
	ErrNotFound     = errors.New("superpdp: 404 introuvable")
	ErrInvalidGrant = errors.New("superpdp: invalid_grant (re-consentement obligatoire)")
)

// APIError porte le statut HTTP et le corps brut (jamais journalisé en entier).
type APIError struct {
	Status int
	Body   string
}

func (e *APIError) Error() string { return fmt.Sprintf("superpdp: HTTP %d", e.Status) }

// RejectedError : 400/422, la plateforme refuse le contenu. Déterministe :
// renvoyer la même facture donnera le même résultat.
type RejectedError struct {
	APIError
	Rules []string // BR-FR-05, PEPPOL-EN16931-R008…
}

func (e *RejectedError) Error() string {
	return fmt.Sprintf("superpdp: HTTP %d refusée %v", e.Status, e.Rules)
}

// TransientError : 429, 5xx, timeout, TLS, DNS. Le tick suivant retente.
type TransientError struct {
	Status int // 0 si erreur réseau
	Err    error
}

func (e *TransientError) Error() string {
	if e.Status == 0 {
		return "superpdp: erreur réseau: " + e.Err.Error()
	}
	return fmt.Sprintf("superpdp: HTTP %d transitoire", e.Status)
}
func (e *TransientError) Unwrap() error { return e.Err }

var ruleRe = regexp.MustCompile(`\b(BR-[A-Z]{1,3}-\d{2,3}|BR-\d{2,3}|PEPPOL-EN16931-R\d{3})\b`)

// ExtractRules repère les codes de règles Schematron dans un corps d'erreur,
// quel que soit son format (JSON, texte, rapport). Dédoublonnés et triés.
func ExtractRules(body string) []string {
	seen := map[string]bool{}
	for _, m := range ruleRe.FindAllString(body, -1) {
		seen[m] = true
	}
	out := make([]string, 0, len(seen))
	for r := range seen {
		out = append(out, r)
	}
	sort.Strings(out)
	return out
}

func classifyHTTP(status int, body string) error {
	switch {
	case status == 401:
		return ErrUnauthorized
	case status == 403:
		return ErrForbidden
	case status == 404:
		return ErrNotFound
	case status == 400 || status == 422:
		return &RejectedError{APIError: APIError{Status: status, Body: body}, Rules: ExtractRules(body)}
	case status == 429 || status >= 500:
		return &TransientError{Status: status}
	default:
		return &APIError{Status: status, Body: body}
	}
}
