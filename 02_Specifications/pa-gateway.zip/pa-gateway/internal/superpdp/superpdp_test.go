package superpdp

import (
	"errors"
	"reflect"
	"testing"
)

func TestMapStatus(t *testing.T) {
	cases := map[string]int{"fr:212": 212, "fr:220": 220, "api:uploaded": 200, "api:received": 202,
		"ppf:refused": 210, "api:invalid": 213, "ppf:payment-received": 212}
	for raw, want := range cases {
		if got, ok := MapStatus(raw); !ok || got != want {
			t.Errorf("%s → %d,%v ; attendu %d", raw, got, ok, want)
		}
	}
	if _, ok := MapStatus("api:something-new"); ok {
		t.Error("code inconnu accepté")
	}
}

func TestLatestKnownStatusSkipsUnknown(t *testing.T) {
	code, ev, ok := LatestKnownStatus([]Event{{StatusCode: "api:uploaded"}, {StatusCode: "fr:202"}, {StatusCode: "x:new"}})
	if !ok || code != 202 || ev.StatusCode != "fr:202" {
		t.Fatalf("got %d %v %v", code, ev, ok)
	}
}

func TestExtractRulesAndClassify(t *testing.T) {
	body := `{"errors":["[BR-FR-05] BT-22 manquant","[BR-FR-05] …","PEPPOL-EN16931-R008 (still status warning)","[BR-CO-10]"]}`
	if got := ExtractRules(body); !reflect.DeepEqual(got, []string{"BR-CO-10", "BR-FR-05", "PEPPOL-EN16931-R008"}) {
		t.Fatalf("règles = %v", got)
	}
	var rej *RejectedError
	if !errors.As(classifyHTTP(400, body), &rej) || len(rej.Rules) != 3 {
		t.Fatal("400 non classé en RejectedError")
	}
	var tr *TransientError
	if !errors.As(classifyHTTP(503, ""), &tr) || !errors.As(classifyHTTP(429, ""), &tr) {
		t.Fatal("5xx/429 non transitoires")
	}
	if !errors.Is(classifyHTTP(403, ""), ErrForbidden) || !errors.Is(classifyHTTP(401, ""), ErrUnauthorized) {
		t.Fatal("401/403 mal classés")
	}
}
