package superpdp

import (
	"encoding/json"
	"strconv"
	"strings"
)

// Les structures ne décrivent que les champs utilisés par la passerelle.
// Tout le reste est conservé brut (json.RawMessage) pour la preuve et l'audit.
// ⚠ À confronter à la spec OpenAPI (api.superpdp.tech, v1.beta) : idéalement,
// générer ces types avec oapi-codegen et ne garder ici que l'enveloppe.

type Session struct {
	CompanyVerificationStatus      string `json:"company_verification_status"` // verified | needs_review | failed
	UserIdentityVerificationStatus string `json:"user_identity_verification_status,omitempty"`
}

type Company struct {
	ID   int64  `json:"id"`
	Name string `json:"name,omitempty"`
}

type Event struct {
	ID         int64           `json:"id"`
	InvoiceID  int64           `json:"invoice_id"`
	StatusCode string          `json:"status_code"` // fr:212, api:uploaded, ppf:refused…
	CreatedAt  string          `json:"created_at,omitempty"`
	Data       json.RawMessage `json:"data,omitempty"` // data.reason : motif (parfois absent, normal sur un 213 de routage)
}

// Reason extrait data.reason s'il existe.
func (e Event) Reason() string {
	var d struct {
		Reason string `json:"reason"`
	}
	_ = json.Unmarshal(e.Data, &d)
	return d.Reason
}

type Invoice struct {
	ID         int64           `json:"id"`
	ExternalID string          `json:"external_id,omitempty"`
	Direction  string          `json:"direction,omitempty"`
	Events     []Event         `json:"events,omitempty"`
	EnInvoice  json.RawMessage `json:"en_invoice,omitempty"`
}

// Page : réponse des routes de liste. Pagination à curseur (starting_after_id).
type Page[T any] struct {
	Data []T `json:"data"`
}

type Token struct {
	AccessToken  string `json:"access_token"`
	RefreshToken string `json:"refresh_token"`
	ExpiresIn    int    `json:"expires_in"`
	TokenType    string `json:"token_type"`
}

// ---- Statuts de cycle de vie -------------------------------------------------

// Final : aucun changement n'est plus attendu, on arrête de suivre la facture.
var finalStatuses = map[int]bool{210: true, 212: true, 213: true}

func IsFinal(code int) bool { return finalStatuses[code] }

var apiCodes = map[string]int{
	"api:uploaded": 200, "api:validated": 200, "api:sent": 200,
	"api:received":     202,
	"api:acknowledged": 204,
	"api:accepted":     205,
	"api:rejected":     213, "api:invalid": 213, "ppf:rejected": 213,
	"ppf:refused":          210,
	"ppf:payment-received": 212,
}

// MapStatus traduit un status_code brut en code XP Z12-012.
// ok=false : code inconnu → à conserver brut, sans écraser le statut courant.
// Les codes fr:NNN passent directement (fr:220, apparu en 1.33.0, inclus).
func MapStatus(raw string) (code int, ok bool) {
	if strings.HasPrefix(raw, "fr:") {
		n, err := strconv.Atoi(strings.TrimPrefix(raw, "fr:"))
		return n, err == nil
	}
	code, ok = apiCodes[raw]
	return code, ok
}

// LatestKnownStatus renvoie le dernier statut connu d'une liste d'événements
// (dans l'ordre fourni par la plateforme), ainsi que l'événement correspondant.
func LatestKnownStatus(events []Event) (code int, ev Event, ok bool) {
	for i := len(events) - 1; i >= 0; i-- {
		if c, known := MapStatus(events[i].StatusCode); known {
			return c, events[i], true
		}
	}
	return 0, Event{}, false
}
