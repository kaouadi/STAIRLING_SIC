// Package tokens fournit un access token frais par tenant.
//
// Règles :
//   - rafraîchissement proactif, 60 s avant expiration ;
//   - rafraîchissement sérialisé par tenant (verrou consultatif) et relecture
//     après verrou : le refresh token tourne, un seul worker doit le dépenser ;
//   - le nouveau couple de jetons est persisté (chiffré) dans la même transaction ;
//   - invalid_grant → état reconnect_required, seule sortie : re-consentement.
package tokens

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	"github.com/stairling/pa-gateway/internal/secret"
	"github.com/stairling/pa-gateway/internal/store"
	"github.com/stairling/pa-gateway/internal/superpdp"
)

var (
	ErrNotConnected        = errors.New("tenant non raccordé à SuperPDP")
	ErrPendingVerification = errors.New("vérification KYB en attente chez SuperPDP")
	ErrReconnectRequired   = errors.New("reconnexion SuperPDP requise (re-consentement)")
)

const refreshMargin = 60 * time.Second

type Source struct {
	DB     *sql.DB
	API    *superpdp.Client
	Sealer *secret.Sealer
	Now    func() time.Time
}

func (s *Source) now() time.Time {
	if s.Now != nil {
		return s.Now()
	}
	return time.Now()
}

// Client renvoie un client SuperPDP lié au jeton frais du tenant, après avoir
// vérifié que l'état du raccordement autorise les appels métier.
func (s *Source) Client(ctx context.Context, tenantID int64) (*superpdp.Scoped, *store.Connection, error) {
	conn, err := store.GetConnection(ctx, s.DB, tenantID)
	if errors.Is(err, store.ErrNotFound) {
		return nil, nil, ErrNotConnected
	}
	if err != nil {
		return nil, nil, err
	}
	switch conn.State {
	case "connected":
	case "pending_verification":
		return nil, conn, ErrPendingVerification
	case "reconnect_required":
		return nil, conn, ErrReconnectRequired
	default:
		return nil, conn, ErrNotConnected
	}
	tok, err := s.Fresh(ctx, tenantID)
	if err != nil {
		return nil, conn, err
	}
	return s.API.As(tok), conn, nil
}

// Fresh renvoie un access token valide au moins refreshMargin.
func (s *Source) Fresh(ctx context.Context, tenantID int64) (string, error) {
	conn, err := store.GetConnection(ctx, s.DB, tenantID)
	if err != nil {
		return "", err
	}
	if tok, ok, err := s.usable(conn); err != nil || ok {
		return tok, err
	}

	var access string
	err = store.WithTx(ctx, s.DB, func(tx *sql.Tx) error {
		if err := store.LockTenantTokens(ctx, tx, tenantID); err != nil {
			return err
		}
		// Relecture après verrou : un autre worker a peut-être déjà rafraîchi.
		conn, err := store.GetConnectionForUpdate(ctx, tx, tenantID)
		if err != nil {
			return err
		}
		if tok, ok, err := s.usable(conn); err != nil || ok {
			access = tok
			return err
		}
		if conn.RefreshTokenEnc == nil {
			return ErrReconnectRequired
		}
		refresh, err := s.Sealer.Open(conn.RefreshTokenEnc)
		if err != nil {
			return err
		}
		t, err := s.API.Refresh(ctx, refresh)
		if errors.Is(err, superpdp.ErrInvalidGrant) {
			// On persiste l'état et on COMMIT : la connexion est morte.
			if err := store.SetState(ctx, tx, tenantID, "reconnect_required", nil); err != nil {
				return err
			}
			access = ""
			return nil
		}
		if err != nil {
			return fmt.Errorf("refresh: %w", err)
		}
		if err := s.Save(ctx, tx, tenantID, t); err != nil {
			return err
		}
		access = t.AccessToken
		return nil
	})
	if err != nil {
		return "", err
	}
	if access == "" {
		return "", ErrReconnectRequired
	}
	return access, nil
}

// Save chiffre et persiste un couple de jetons (échange de code ou refresh).
func (s *Source) Save(ctx context.Context, q store.DBTX, tenantID int64, t *superpdp.Token) error {
	a, err := s.Sealer.Seal(t.AccessToken)
	if err != nil {
		return err
	}
	r, err := s.Sealer.Seal(t.RefreshToken)
	if err != nil {
		return err
	}
	exp := s.now().Add(time.Duration(t.ExpiresIn) * time.Second)
	return store.SaveTokens(ctx, q, tenantID, a, r, exp)
}

func (s *Source) usable(c *store.Connection) (string, bool, error) {
	if c.State == "reconnect_required" {
		return "", false, ErrReconnectRequired
	}
	if c.AccessTokenEnc == nil || !c.ExpiresAt.Valid || c.ExpiresAt.Time.Sub(s.now()) <= refreshMargin {
		return "", false, nil
	}
	tok, err := s.Sealer.Open(c.AccessTokenEnc)
	return tok, err == nil, err
}
