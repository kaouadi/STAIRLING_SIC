// Package tracking orchestre la synchronisation périodique d'un tenant
// (job "sync", équivalent de PDPSYNC) :
//
//  1. événements (toujours) : statuts de nos factures émises + factures reçues ;
//  2. filet de sécurité : relecture directe des factures émises encore en vol ;
//  3. réception (si activée) : factures, détail, fichier natif.
//
// Le job se replanifie lui-même à la fin (clé d'unicité sync:<tenant>).
// Un échec sur une passe n'empêche pas les suivantes.
package tracking

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"time"

	"github.com/stairling/pa-gateway/internal/queue"
	"github.com/stairling/pa-gateway/internal/reception"
	"github.com/stairling/pa-gateway/internal/store"
	"github.com/stairling/pa-gateway/internal/superpdp"
	"github.com/stairling/pa-gateway/internal/tokens"
)

type Syncer struct {
	DB        *sql.DB
	Tokens    *tokens.Source
	Collector *reception.Collector
	Log       *slog.Logger
	Interval  time.Duration
	Now       func() time.Time
}

func (s *Syncer) HandleSync(ctx context.Context, job *queue.Job) error {
	tenantID := job.TenantID
	log := s.Log.With("flow", "track", "tenant_id", tenantID)

	api, conn, err := s.Tokens.Client(ctx, tenantID)
	if errors.Is(err, tokens.ErrReconnectRequired) || errors.Is(err, tokens.ErrNotConnected) {
		log.Warn("sync", "event", "sync.stopped", "error", err.Error())
		return nil // la synchro reprendra au raccordement (enrollment replanifie)
	}
	if err != nil {
		if errors.Is(err, tokens.ErrPendingVerification) {
			return s.reschedule(ctx, job)
		}
		return queue.Snooze(15*time.Minute, err)
	}

	var errs []error
	if n, err := s.Collector.PassEvents(ctx, tenantID, api); err != nil {
		errs = append(errs, fmt.Errorf("events: %w", err))
	} else if n > 0 {
		log.Info("sync", "event", "receive.events", "count", n)
	}
	if err := s.trackInFlight(ctx, tenantID, api, log); err != nil {
		errs = append(errs, fmt.Errorf("track: %w", err))
	}
	if s.receptionEnabled(conn) {
		if n, err := s.Collector.PassInvoices(ctx, tenantID, api); err != nil {
			errs = append(errs, fmt.Errorf("invoices: %w", err))
		} else if n > 0 {
			log.Info("sync", "event", "receive.invoices", "count", n)
		}
		// Détail et natif après la liste, pour traiter les nouvelles dans le même tick.
		if _, err := s.Collector.PassDetail(ctx, tenantID, api); err != nil {
			errs = append(errs, fmt.Errorf("detail: %w", err))
		}
		if _, err := s.Collector.PassNative(ctx, tenantID, api); err != nil {
			errs = append(errs, fmt.Errorf("native: %w", err))
		}
	} else {
		log.Info("sync", "event", "receive.invoices.skipped")
	}

	if err := s.reschedule(ctx, job); err != nil {
		return err
	}
	if len(errs) > 0 {
		log.Warn("sync", "event", "sync.partial", "error", errors.Join(errs...).Error())
	}
	return nil // le prochain tick est déjà planifié : pas de retry immédiat
}

// trackInFlight relit les factures émises non finales : filet de sécurité si
// un événement a été manqué. Un échec sur une facture ne bloque pas le lot.
func (s *Syncer) trackInFlight(ctx context.Context, tenantID int64, api *superpdp.Scoped, log *slog.Logger) error {
	outs, err := store.InFlight(ctx, s.DB, tenantID)
	if err != nil {
		return err
	}
	var first error
	for _, o := range outs {
		inv, err := api.GetInvoice(ctx, o.PDPInvoiceID.Int64)
		if err != nil {
			if first == nil {
				first = err
			}
			continue
		}
		code, ev, ok := superpdp.LatestKnownStatus(inv.Events)
		if !ok {
			continue
		}
		raw, _ := json.Marshal(ev)
		changed, err := store.RecordStatus(ctx, s.DB, o.ID, &code, ev.StatusCode, ev.Reason(), raw)
		if err != nil && first == nil {
			first = err
		}
		if changed {
			log.Info("sync", "event", "track.status", "outbound_id", o.ID, "status_code", code, "raw_code", ev.StatusCode)
		}
	}
	return first
}

func (s *Syncer) receptionEnabled(c *store.Connection) bool {
	now := time.Now()
	if s.Now != nil {
		now = s.Now()
	}
	return c.ReceptionEnabledFrom.Valid && !now.Before(c.ReceptionEnabledFrom.Time)
}

// reschedule planifie le tick suivant. La clé dérive de l'identifiant du job
// courant : toujours distincte de la sienne (même s'il a tourné avant son
// créneau), et un job rejoué ne crée pas deux successeurs.
func (s *Syncer) reschedule(ctx context.Context, job *queue.Job) error {
	_, err := queue.Enqueue(ctx, s.DB, "sync", job.TenantID, map[string]any{},
		queue.EnqueueOpts{UniqueKey: fmt.Sprintf("sync:%d:after:%d", job.TenantID, job.ID), Delay: s.Interval})
	return err
}

// slotKey : clé du job initial d'un créneau (garde-fou, raccordement).
func slotKey(tenantID int64, at time.Time, interval time.Duration) string {
	return fmt.Sprintf("sync:%d:%d", tenantID, at.Truncate(interval).Unix())
}

// EnsureScheduled garantit qu'un job de synchro actif existe pour le tenant ;
// sinon il en crée un, immédiat. Appelé au raccordement et par le garde-fou
// périodique de main (rattrape un tenant dont la chaîne se serait rompue).
func EnsureScheduled(ctx context.Context, q store.DBTX, tenantID int64, interval time.Duration) error {
	var exists bool
	if err := q.QueryRowContext(ctx, `SELECT EXISTS (SELECT 1 FROM pa_jobs
		WHERE kind='sync' AND tenant_id=$1 AND state IN ('available','running'))`, tenantID).Scan(&exists); err != nil {
		return err
	}
	if exists {
		return nil
	}
	_, err := queue.Enqueue(ctx, q, "sync", tenantID, map[string]any{},
		queue.EnqueueOpts{UniqueKey: slotKey(tenantID, time.Now(), interval) + ":now"})
	return err
}
