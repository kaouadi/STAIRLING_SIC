// Package vault stocke les pièces probantes (fichiers natifs reçus).
// En production : S3 avec versioning activé (un PUT sur une clé existante
// écrase sans trace sinon). Ici : implémentation fichier pour le dev et les tests.
package vault

import (
	"context"
	"os"
	"path/filepath"
)

type Store interface {
	Put(ctx context.Context, key string, data []byte) error
}

type FS struct{ Root string }

func (f FS) Put(_ context.Context, key string, data []byte) error {
	p := filepath.Join(f.Root, filepath.FromSlash(key))
	if err := os.MkdirAll(filepath.Dir(p), 0o750); err != nil {
		return err
	}
	// Écriture atomique : fichier temporaire puis renommage.
	tmp := p + ".tmp"
	if err := os.WriteFile(tmp, data, 0o640); err != nil {
		return err
	}
	return os.Rename(tmp, p)
}
