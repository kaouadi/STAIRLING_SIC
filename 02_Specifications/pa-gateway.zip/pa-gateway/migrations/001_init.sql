-- Passerelle PA : schéma unique, cloisonné par tenant_id.
-- (Si Stairling Enterprise garde un schéma Postgres par tenant, ces tables
--  peuvent être créées dans chaque schéma et tenant_id devient redondant.)

-- 1. Raccordement d'un tenant à SuperPDP ------------------------------------
CREATE TABLE IF NOT EXISTS pa_connections (
    tenant_id              BIGINT PRIMARY KEY,
    siren                  TEXT NOT NULL,
    login_email            TEXT NOT NULL,
    state                  TEXT NOT NULL DEFAULT 'disconnected'
        CHECK (state IN ('disconnected','pending_verification','connected','reconnect_required')),
    kyb_status             TEXT,                 -- verified | needs_review | failed
    company_id             BIGINT,
    access_token_enc       BYTEA,
    refresh_token_enc      BYTEA,
    expires_at             TIMESTAMPTZ,
    emission_enabled_from  DATE,                 -- NULL = émission coupée
    reception_enabled_from DATE,                 -- NULL = réception coupée (événements toujours ingérés)
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Demandes OAuth en cours : state anti-CSRF à usage unique + verifier PKCE chiffré.
CREATE TABLE IF NOT EXISTS pa_oauth_requests (
    state        TEXT PRIMARY KEY,
    tenant_id    BIGINT NOT NULL,
    verifier_enc BYTEA NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    consumed_at  TIMESTAMPTZ
);

-- 2. Émission ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pa_outbound (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       BIGINT NOT NULL,
    external_id     TEXT NOT NULL,               -- identifiant de la facture côté Stairling Enterprise
    payload         JSONB NOT NULL,              -- modèle EN 16931 soumis
    issue_date      DATE NOT NULL,
    pdp_invoice_id  BIGINT,                      -- non NULL = transmise : ne repart jamais
    status_code     INT,                         -- dernier statut XP Z12-012 (200, 213…)
    nature          TEXT,                        -- invalid | blocked | refused | failed | exhausted
    attempts        INT NOT NULL DEFAULT 0,      -- échecs déterministes seulement (plafond 5)
    last_error      TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, external_id)
);

CREATE TABLE IF NOT EXISTS pa_status_history (
    id           BIGSERIAL PRIMARY KEY,
    outbound_id  BIGINT NOT NULL REFERENCES pa_outbound(id),
    status_code  INT,                            -- NULL si code brut inconnu (conservé pour audit)
    raw_code     TEXT NOT NULL,
    reason       TEXT,
    raw          JSONB,
    at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 3. Réception ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pa_inbound (
    tenant_id       BIGINT NOT NULL,
    pdp_invoice_id  BIGINT NOT NULL,
    raw             JSONB NOT NULL,              -- ligne de liste, telle que reçue
    detail          JSONB,                       -- GET /invoices/{id} complet
    native_key      TEXT,                        -- clé du fichier natif au coffre
    native_sha256   TEXT,
    decision        TEXT,                        -- approved | refused
    decision_sent   BOOLEAN NOT NULL DEFAULT false,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (tenant_id, pdp_invoice_id)
);

-- Événements dans les deux sens. Pas de clé étrangère : un événement peut
-- arriver avant sa facture, la jointure se referme au passage suivant.
CREATE TABLE IF NOT EXISTS pa_events (
    tenant_id       BIGINT NOT NULL,
    pdp_event_id    BIGINT NOT NULL,
    pdp_invoice_id  BIGINT NOT NULL,
    raw_code        TEXT NOT NULL,
    raw             JSONB NOT NULL,
    PRIMARY KEY (tenant_id, pdp_event_id)
);

-- Curseurs de collecte. BIGINT : jamais de MAX() lexicographique.
CREATE TABLE IF NOT EXISTS pa_cursors (
    tenant_id BIGINT NOT NULL,
    name      TEXT NOT NULL,                     -- invoices_in | events
    value     BIGINT NOT NULL DEFAULT 0,
    PRIMARY KEY (tenant_id, name)
);

-- 4. File de jobs (Postgres, SELECT … FOR UPDATE SKIP LOCKED) ---------------
CREATE TABLE IF NOT EXISTS pa_jobs (
    id           BIGSERIAL PRIMARY KEY,
    kind         TEXT NOT NULL,
    tenant_id    BIGINT NOT NULL,
    args         JSONB NOT NULL DEFAULT '{}',
    unique_key   TEXT,
    state        TEXT NOT NULL DEFAULT 'available'
        CHECK (state IN ('available','running','done','discarded')),
    run_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    attempts     INT NOT NULL DEFAULT 0,
    max_attempts INT NOT NULL DEFAULT 25,
    locked_at    TIMESTAMPTZ,
    last_error   TEXT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS pa_jobs_fetch ON pa_jobs (run_at) WHERE state = 'available';
-- Un seul job actif par clé d'unicité (ex. « sync:42 », « send:42:FA-2026-001 »).
CREATE UNIQUE INDEX IF NOT EXISTS pa_jobs_unique_active
    ON pa_jobs (unique_key) WHERE unique_key IS NOT NULL AND state IN ('available','running');
