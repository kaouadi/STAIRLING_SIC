// Package migrations embarque le schéma SQL de la passerelle.
package migrations

import (
	"context"
	"database/sql"
	_ "embed"
)

//go:embed 001_init.sql
var initSQL string

// Apply exécute le schéma (idempotent : IF NOT EXISTS partout).
func Apply(ctx context.Context, db *sql.DB) error {
	_, err := db.ExecContext(ctx, initSQL)
	return err
}
